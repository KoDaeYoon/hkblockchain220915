package controller.goods;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import model.DAO.GoodsDAO;
import model.DTO.GoodsDTO;

public class GoodsDeleteController {
	public void execute(HttpServletRequest request) {
		String goodsNum = request.getParameter("goodsNum");
		
		GoodsDAO dao = new GoodsDAO();
		//----시스템에서도 이미지삭제를 위한 추가--------------
		GoodsDTO dto = dao.selectOne(goodsNum);
		String goodsImages[] = dto.getGoodsImage().split("`");
		if(goodsImages.length >= 1) {
			String realPath = request.getServletContext().getRealPath("images");
			File file = null;
			for(String fileName : goodsImages) {
				file = new File(realPath + "/" + fileName);
				if(file.exists()) file.delete();
		 	}
		}
		//---------------------------------
		dao.goodsDelete(goodsNum);
	}
}
