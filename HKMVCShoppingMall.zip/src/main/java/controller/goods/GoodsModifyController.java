package controller.goods;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.DAO.GoodsDAO;
import model.DTO.AuthInfo;
import model.DTO.GoodsDTO;

public class GoodsModifyController {
	public void execute(HttpServletRequest request) {
		String goodsNum = request.getParameter("goodsNum");
		String goodsName = request.getParameter("goodsName");
		String goodsPrice = request.getParameter("goodsPrice");
		String goodsContent = request.getParameter("goodsContent");
		String company = request.getParameter("company");
		HttpSession session = request.getSession();
		AuthInfo authInfo = (AuthInfo)session.getAttribute("dto");
		String employeeUptNum = authInfo.getUserId();
		
		GoodsDTO dto = new GoodsDTO();
		dto.setGoodsNum(goodsNum);
		dto.setCompany(company);
		dto.setGoodsName(goodsName);
		dto.setGoodsContent(goodsContent);
		dto.setGoodsPrice(Integer.parseInt(goodsPrice));
		dto.setEmployeeUptNum(employeeUptNum);
		
		GoodsDAO dao = new GoodsDAO();
		dao.goodsUpdate(dto);
		
		
	}
}
