package controller.member;

import javax.servlet.http.HttpServletRequest;

import model.DAO.MemberDAO;

public class MemberDelController {
	public void execute(HttpServletRequest request) {
		String memNo = request.getParameter("memNo");
		MemberDAO dao = new MemberDAO();
		dao.memDel(memNo);
	}
}
