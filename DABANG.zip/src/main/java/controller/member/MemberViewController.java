package controller.member;

import javax.servlet.http.HttpServletRequest;

import model.DAO.MemberDAO;
import model.DTO.MemberDTO;

public class MemberViewController {
	public void execute(HttpServletRequest request) {
		String memNo = request.getParameter("memNo");
		MemberDAO dao = new MemberDAO();
		MemberDTO dto = dao.memberOne(memNo);
		request.setAttribute("memDTO", dto);
	}
}
