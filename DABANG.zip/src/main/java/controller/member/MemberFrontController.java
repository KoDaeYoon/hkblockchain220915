package controller.member;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MemberFrontController extends HttpServlet implements Servlet{
	protected void doPro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		if(command.equals("/memberList.mem")) {
			MemberListController action = new MemberListController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("member/memberList.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/memberWrite.mem")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("member/memberJoin.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/memberRegist.mem")) {
			MemberJoinController action = new MemberJoinController();
			action.execute(request);
			response.sendRedirect("memberList.mem");
		}else if(command.equals("/memberDetail.mem")) {
			MemberViewController action = new MemberViewController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("member/memberView.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/memberModify.mem")) {
			MemberViewController action = new MemberViewController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("member/memberModify.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/memberUpdate.mem")) {
			MemberUpdateController action = new MemberUpdateController();
			action.execute(request);
			response.sendRedirect("memberDetail.mem?memNo="+request.getParameter("memNo"));
		}else if(command.equals("/memberDel.mem")) {
			MemberDelController action = new MemberDelController();
			action.execute(request);
			response.sendRedirect("memberList.mem");
		}
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPro(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPro(req, resp);
	}
}
