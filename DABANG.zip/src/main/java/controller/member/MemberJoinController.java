package controller.member;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import model.DAO.MemberDAO;
import model.DTO.MemberDTO;

public class MemberJoinController {
	public void execute(HttpServletRequest request) {
		String memNo = request.getParameter("memNo");
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String memId = request.getParameter("memId");
		String memPw = request.getParameter("memPw");
		String memBirth = request.getParameter("memBirth");
		String memGender = request.getParameter("memGender");
		String memTel = request.getParameter("memTel");
		String memEmail = request.getParameter("memEmail");
		
		Date date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		try {
			date = sdf.parse(memBirth);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		MemberDTO memDTO = new MemberDTO();
		memDTO.setFirstName(firstName);
		memDTO.setLastName(lastName);
		memDTO.setMemBirth(date);
		memDTO.setMemEmail(memEmail);
		memDTO.setMemGender(memGender);
		memDTO.setMemId(memId);
		memDTO.setMemNo(memNo);
		memDTO.setMemPw(memPw);
		memDTO.setMemTel(memTel);
		
		MemberDAO dao = new MemberDAO();
		dao.memJoin(memDTO);
	}
}
