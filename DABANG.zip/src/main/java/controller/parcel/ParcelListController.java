package controller.parcel;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import model.DAO.ParcelDAO;
import model.DTO.ParcelDTO;

public class ParcelListController {
	public void execute(HttpServletRequest request) {
		ParcelDAO dao = new ParcelDAO();
		List<ParcelDTO> list = dao.selectAll();
		request.setAttribute("list", list);
	}
}
