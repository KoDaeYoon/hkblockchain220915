package controller.parcel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.DAO.ParcelDAO;
import model.DTO.AuthInfo1DTO;
import model.DTO.ParcelDTO;

public class ParcelUpdateController {
	public void execute(HttpServletRequest request) {
		String parcelNo = request.getParameter("parcelNo");
		String brand = request.getParameter("brand");
		String brandNo = request.getParameter("brandNo");
		String constructFirmName = request.getParameter("constructFirmName");
		String developerName = request.getParameter("developerName");
		String parcelAddr = request.getParameter("parcelAddr");
		String parcelPrice = request.getParameter("parcelPrice");
		String buildingType = request.getParameter("buildingType");
		String supplyType = request.getParameter("supplyType");
		String monopolyRight = request.getParameter("monopolyRight");
		String restrictRegion = request.getParameter("restrictRegion");
		String priceCeiling = request.getParameter("priceCeiling");
		String restrictPeriod = request.getParameter("restrictPeriod");
		String area = request.getParameter("area");
		String recruitDate = request.getParameter("recruitDate");
		String moveDate = request.getParameter("moveDate");
		String parcelTel = request.getParameter("parcelTel");
		String totalHouseNo = request.getParameter("totalHouseNo");
		String parcelHouseNo = request.getParameter("parcelHouseNo");
		String lowHighFloor = request.getParameter("lowHighFloor");
		String housingArea = request.getParameter("housingArea");
		
		Date recDate = null;
		Date movDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		try {
			recDate = sdf.parse(recruitDate);
			movDate = sdf.parse(moveDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		HttpSession session = request.getSession();
	    AuthInfo1DTO authInfo = (AuthInfo1DTO)session.getAttribute("dto11");
	    String empNo = authInfo.getUserId();
		
		ParcelDTO parDTO = new ParcelDTO();
		parDTO.setArea(housingArea);
		parDTO.setBrand(brandNo);
		parDTO.setBrandNo(brandNo);
		parDTO.setBuildingType(buildingType);
		parDTO.setConstructFirmName(constructFirmName);
		parDTO.setDeveloperName(developerName);
		parDTO.setHousingArea(housingArea);
		parDTO.setLowHighFloor(lowHighFloor);
		parDTO.setMonopolyRight(monopolyRight);
		parDTO.setMoveDate(movDate);
		parDTO.setParcelAddr(parcelAddr);
		parDTO.setParcelHouseNo(Integer.parseInt(parcelHouseNo));
		parDTO.setParcelNo(parcelNo);
		parDTO.setParcelPrice(parcelPrice);
		parDTO.setParcelTel(parcelTel);
		parDTO.setPriceCeiling(priceCeiling);
		parDTO.setRecruitDate(recDate);
		parDTO.setRestrictPeriod(restrictPeriod);
		parDTO.setRestrictRegion(restrictRegion);
		parDTO.setSupplyType(supplyType);
		parDTO.setTotalHouseNo(Integer.parseInt(totalHouseNo));
		parDTO.setEmpUpdateNo(empNo);
		
		ParcelDAO dao = new ParcelDAO();
		dao.parUpdate(parDTO);
	}
}
