package controller.parcel;

import javax.servlet.http.HttpServletRequest;

import model.DAO.ParcelDAO;

public class ParcelDelController {
	public void execute(HttpServletRequest request) {
		String parcelNo = request.getParameter("parcelNo");
		ParcelDAO dao = new ParcelDAO();
		dao.parDel(parcelNo);
	}
}
