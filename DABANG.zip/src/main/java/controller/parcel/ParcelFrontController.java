package controller.parcel;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ParcelFrontController extends HttpServlet implements Servlet{
	protected void doPro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		if(command.equals("/parcel.par")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("parcel/parcel.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/parcelList.par")) {
			ParcelListController action = new ParcelListController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("parcel/parcelList.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/parcelWrite.par")){
			RequestDispatcher dispatcher = request.getRequestDispatcher("parcel/parcelWrite.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/parcelUpload.par")) {
			ParcelUploadController action = new ParcelUploadController();
			action.execute(request);
			response.sendRedirect("parcelList.par");
		}else if(command.equals("/parcelDetail.par")) {
			ParcelDetailController action = new ParcelDetailController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("parcel/parcelDetail.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/parcelModify.par")) {
			ParcelDetailController action = new ParcelDetailController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("parcel/parcelModify.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/parcelUpdate.par")) {
			ParcelUpdateController action = new ParcelUpdateController();
			action.execute(request);
			response.sendRedirect("parcelDetail.par?parcelNo="+request.getParameter("parcelNo"));
		}else if(command.equals("/parcelDel.par")) {
			ParcelDelController action = new ParcelDelController();
			action.execute(request);
			response.sendRedirect("parcelDetail.par?parcelNo="+request.getParameter("parcelNo"));
		}
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPro(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPro(req, resp);
	}
}
