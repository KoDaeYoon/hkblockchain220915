package controller.user;

import javax.servlet.http.HttpServletRequest;

import model.DAO.InquiryDAO;
import model.DTO.InquiryDTO;

public class InquiryDetailController {
	public void execute(HttpServletRequest request) {
		String inquirySubject = request.getParameter("inquirySubject");
		InquiryDAO inquiryDAO = new InquiryDAO();
		InquiryDTO inquiryDTO = inquiryDAO.selectOne(inquirySubject);
		request.setAttribute("dto22", inquiryDTO);
		System.out.println(inquiryDTO.getInquirySubject());
	}
}
