package controller.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.DAO.InquiryDAO;
import model.DTO.AuthInfo1DTO;

public class InquiryReplyController {
	public void execute(HttpServletRequest request) {
		String inquirySubject = request.getParameter("inquirySubject");
		String answerReply = request.getParameter("answerReply");
		
		HttpSession session = request.getSession();
		AuthInfo1DTO authInfo = (AuthInfo1DTO)session.getAttribute("dto11");
		
		InquiryDAO dao = new InquiryDAO();
		dao.inquiryReplyUpdate(inquirySubject, answerReply, authInfo.getUserId());
	}
}
