package controller.user;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import model.DAO.UserDAO;
import model.DTO.UserDTO;

public class UserWriteController {
	public void execute(HttpServletRequest request) {
		
		String memNo = request.getParameter("memNo");
		String lastName = request.getParameter("lastName");
		String firstName = request.getParameter("firstName");
		String memId = request.getParameter("memId");
		String memPw = request.getParameter("memPw");
		String memGender = request.getParameter("memGender");
		String memTel = request.getParameter("memTel");
		String memBirth = request.getParameter("memBirth");
		String memEmail = request.getParameter("memEmail");
		
		
		Date date =null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		try {
		   date= sdf.parse(memBirth);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		UserDTO dto = new UserDTO();
		dto.setMemNo(memNo);
		dto.setLastName(lastName);
		dto.setFirstName(firstName);
		dto.setMemId(memId);
		dto.setMemPw(memPw);
		dto.setMemGender(memGender);
		dto.setMemTel(memTel);
		dto.setMembirth(date);
		dto.setMemEmail(memEmail);
		
		UserDAO dao = new UserDAO();
	    dao.userInsert(dto);
	}
}
