package controller.user;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.member.MemberListController;

public class UserFrontController extends HttpServlet implements Servlet {
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		
	if(command.equals("/Agree.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/agree.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/userWrite.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/userForm.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/userRegist.agr")) {
		UserWriteController action = new UserWriteController();
		action.execute(request);
		response.sendRedirect("main.jsp");
	//12-08
	}else if(command.equals("/userMyPage.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/userMyDaBang.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/simpleInquiry.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/simpleInquiry.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/inquiryReward.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/inquiryReward.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/telInquiry.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/telInquiry.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/inquiryHistory.agr")) {
		InquiryListController action = new InquiryListController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/inquiryHistory.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/inquiryOne.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/inquiryOne.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/question1.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/question1.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/question2.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/question2.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/question3.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/question3.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/question4.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/question4.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/question5.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/question5.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/question.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/question.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/inquiry1.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/inquiry1.jsp");
		dispatcher.forward(request, response);
	//회원
	}else if(command.equals("/announcement.agr")) {
		AnnounceListController action = new AnnounceListController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/announcement.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/announceDetail.agr")) {
		AnnounceDetailController action = new AnnounceDetailController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/announceDetail.jsp");
		dispatcher.forward(request, response);
	}
	//직원
	else if(command.equals("/announceList.agr")) {
		AnnounceListController action = new AnnounceListController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/announceList.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/announceWriteEmp.agr")) {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/announceWrite.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/announceRegistEmp.agr")) {
		AnnounceWriteController action = new AnnounceWriteController();
		action.execute(request);
		response.sendRedirect("announceList.agr");
	}else if(command.equals("/announceDetailEmp.agr")) {
		AnnounceDetailController action = new AnnounceDetailController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/announceDetailEmp.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/announceUpdateEmp.agr")) {
		AnnounceDetailController action = new AnnounceDetailController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/announceModify.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/announceModifyEmp.agr")) {
		AnnouceModifyController action = new AnnouceModifyController();
		action.execute(request);
		response.sendRedirect("announceDetailEmp.agr?announceSubject="+request.getParameter("announceSubject"));
	}else if(command.equals("/announceDeleteEmp.agr")) {
		AnnounceDeleteController action = new AnnounceDeleteController();
		action.execute(request);
		response.sendRedirect("announcementList.agr");
	}else if(command.equals("/inquiryRegist.agr")) {
		InquiryWriteController action = new InquiryWriteController();
		action.execute(request);
		response.sendRedirect("inquiryHistory.agr");
	}else if(command.equals("/inquiryDetail.agr")) {
		InquiryDetailController action = new InquiryDetailController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/inquiryDetail.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/inquiryUpdate.agr")) {
		InquiryDetailController action = new InquiryDetailController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/inquiryModify.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/inquiryModify.agr")) {
		InquiryModifyController action = new InquiryModifyController();
		action.execute(request);
		response.sendRedirect("inquiryDetail.agr?inquirySubject="+request.getParameter("inquirySubject"));
	}else if(command.equals("/inquiryDelete.agr")) {
		InquiryDeleteController action = new InquiryDeleteController();
		action.execute(request);
		response.sendRedirect("inquiryHistory.agr");
	}else if(command.equals("/userInfo.agr")) {
		MemberListController action = new MemberListController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/userInfo.jsp");
		dispatcher.forward(request, response);
	//직원 문의 답변
	}else if(command.equals("/empInquiryList.agr")) {
		InquiryListEmpController action = new InquiryListEmpController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("empMyPage/empInquiryList.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/inquiryDetailEmp.agr")) {
		InquiryDetailController action = new InquiryDetailController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("empMyPage/inquiryDetailEmp.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/inquiryReplyEmp.agr")) {
		InquiryReplyController action = new InquiryReplyController();
		action.execute(request);
		response.sendRedirect("inquiryDetailEmp.agr?inquirySubject="+request.getParameter("inquirySubject"));
	}else if(command.equals("/inquiryDeleteEmp.agr")) {
		InquiryDeleteEmpController action = new InquiryDeleteEmpController();
		action.execute(request);
		response.sendRedirect("empInquiryList.agr");
	}else if (command.equals("/idCheckPro.agr")) {
		IdCheckController action = new IdCheckController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/userForm.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/UserIdChk.agr")) {
		UserIdCheckController action = new UserIdCheckController();
		action.execute(request);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user/userIdChk.jsp");
		dispatcher.forward(request, response);
	}
}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		doProcess(req, resp);
	}@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		doProcess(req, resp);
	}
	
}
		
