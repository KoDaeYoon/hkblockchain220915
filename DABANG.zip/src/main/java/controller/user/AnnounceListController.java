package controller.user;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import model.DAO.AnnounceDAO;
import model.DTO.AnnounceDTO;

public class AnnounceListController {
	public void execute(HttpServletRequest request) {
		String announceSubject = request.getParameter("announceSubject");
		AnnounceDAO announceDAO = new AnnounceDAO();
		List<AnnounceDTO> list = announceDAO.selectAll();
		request.setAttribute("list", list);
	}
}
