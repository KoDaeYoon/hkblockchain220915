package controller.user;

import javax.servlet.http.HttpServletRequest;

import model.DAO.AnnounceDAO;
import model.DTO.AnnounceDTO;


public class AnnounceDetailController {
	public void execute(HttpServletRequest request) {
		String announceSubject = request.getParameter("announceSubject");
		AnnounceDAO announceDAO = new AnnounceDAO();
		AnnounceDTO announceDTO = announceDAO.selectOne(announceSubject);
		request.setAttribute("dto12", announceDTO);
	}
}
