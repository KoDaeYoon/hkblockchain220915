package controller.user;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.DAO.InquiryDAO;
import model.DAO.UserDAO;
import model.DTO.AuthInfo1DTO;
import model.DTO.InquiryDTO;
import model.DTO.MemberDTO;


public class InquiryListController {
	public void execute(HttpServletRequest request) {
		String inquirySubject = request.getParameter("inquirySubject");
		HttpSession session = request.getSession();
		AuthInfo1DTO authInfo1 = (AuthInfo1DTO)session.getAttribute("dto11");
		String memNo = authInfo1.getUserId();
		UserDAO userDAO = new UserDAO();
	    MemberDTO memDTO = new MemberDTO();
	    memDTO = userDAO.userOne(memNo);
		InquiryDAO inquiryDAO = new InquiryDAO();
		List<InquiryDTO> list = inquiryDAO.selectAll();
		request.setAttribute("list", list);
		request.setAttribute("memDTO", memDTO);
	}
}
