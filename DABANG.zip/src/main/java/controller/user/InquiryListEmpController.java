package controller.user;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import model.DAO.InquiryDAO;
import model.DTO.InquiryDTO;

public class InquiryListEmpController {
	public void execute(HttpServletRequest request) {
		String inquirySubject = request.getParameter("inquirySubject");
		InquiryDAO dao = new InquiryDAO();
		List<InquiryDTO> list = dao.inquirySelectAll();
		request.setAttribute("list", list);
	}
}
