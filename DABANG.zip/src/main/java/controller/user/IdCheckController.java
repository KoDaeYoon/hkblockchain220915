package controller.user;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.DAO.MemberDAO;
import model.DTO.AuthInfo1DTO;
import model.DTO.MemberDTO;

public class IdCheckController {
	public void execute(HttpServletRequest request) {
			
		HttpSession session = request.getSession();
		AuthInfo1DTO authInfo = (AuthInfo1DTO) session.getAttribute("dto11");
		String memId = authInfo.getUserId();
		MemberDAO dao = new MemberDAO();
		List<MemberDTO> list = dao.selectAll();
		request.setAttribute("list", list);

	}

}
