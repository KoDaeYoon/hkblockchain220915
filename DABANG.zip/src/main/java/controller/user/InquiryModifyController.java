package controller.user;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import model.DAO.InquiryDAO;
import model.DTO.InquiryDTO;

public class InquiryModifyController {
	public void execute(HttpServletRequest request)  {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String inquiryType = request.getParameter("inquiryType");
		String inquirySubject = request.getParameter("inquirySubject");
		String inquiryContent = request.getParameter("inquiryContent");
		
		
		InquiryDTO inquiryDTO = new InquiryDTO();
		inquiryDTO.setInquiryContent(inquiryContent);
		inquiryDTO.setInquirySubject(inquirySubject);
		inquiryDTO.setInquiryType(inquiryType);
		
		InquiryDAO inquiryDAO = new InquiryDAO();
		inquiryDAO.inquiryUpdate(inquiryDTO);
		
	}
}
