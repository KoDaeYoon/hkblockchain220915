package controller.user;

import javax.servlet.http.HttpServletRequest;

import model.DAO.UserDAO;
import model.DTO.UserDTO;

public class UserIdCheckController {
	public void execute(HttpServletRequest request) {
		String memId = request.getParameter("memId");
		System.out.println(memId);
		UserDAO dao = new UserDAO();
		UserDTO dto = dao.userIdChkSelectOne(memId);
		request.setAttribute("dto", dto);
	}

}
