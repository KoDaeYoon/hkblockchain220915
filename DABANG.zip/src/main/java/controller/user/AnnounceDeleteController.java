package controller.user;

import javax.servlet.http.HttpServletRequest;

import model.DAO.AnnounceDAO;

public class AnnounceDeleteController {
	public void execute(HttpServletRequest request) {
		String announceSubject = request.getParameter("announceSubject");
		AnnounceDAO announceDAO = new AnnounceDAO();
		announceDAO.annDelete(announceSubject);
	}
}
