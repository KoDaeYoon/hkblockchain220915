package controller.user;

import javax.servlet.http.HttpServletRequest;

import model.DAO.InquiryDAO;


public class InquiryDeleteController {
	public void execute(HttpServletRequest request) {
		String inquirySubject = request.getParameter("inquirySubject");
		InquiryDAO inquiryDAO = new InquiryDAO();
		inquiryDAO.inquiryDelete(inquirySubject);
	}
}
