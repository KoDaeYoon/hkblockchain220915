package controller.user;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import model.DAO.InquiryDAO;
import model.DAO.UserDAO;
import model.DTO.AuthInfo1DTO;
import model.DTO.InquiryDTO;
import model.DTO.MemberDTO;

public class InquiryWriteController {
	public void execute(HttpServletRequest request) throws IOException {
		int fileSize = 1024 * 1024 * 100 ;
		String realPath = request.getServletContext().getRealPath("user/images");
		MultipartRequest multi = new MultipartRequest(request, realPath,fileSize,"utf-8", new DefaultFileRenamePolicy());
		String inquiryDate = multi.getParameter("inquiryDate");
		String inquiryType = multi.getParameter("inquiryType");
		String inquirySubject = multi.getParameter("inquirySubject");
		String inquiryContent = multi.getParameter("inquiryContent");
		String inquiryImage1 = multi.getFilesystemName("inquiryImage1");
		String inquiryImage2 = multi.getFilesystemName("inquiryImage2");
		String inquiryImage3 = multi.getFilesystemName("inquiryImage3");
		
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		Date date = null;
		try {
			date = sdf.parse(inquiryDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		HttpSession session = request.getSession();
	    AuthInfo1DTO authInfo = (AuthInfo1DTO)session.getAttribute("dto11");
	    UserDAO dao = new UserDAO();
	    String memNo = authInfo.getUserId();
	    MemberDTO memDTO = new MemberDTO();
	    memDTO = dao.userOne(memNo);
		
		InquiryDTO inquiryDTO = new InquiryDTO();
		inquiryDTO.setInquiryContent(inquiryContent);
		inquiryDTO.setInquiryDate(date);
		inquiryDTO.setInquiryImage1(inquiryImage1);
		inquiryDTO.setInquiryImage2(inquiryImage2);
		inquiryDTO.setInquiryImage3(inquiryImage3);
		inquiryDTO.setInquirySubject(inquirySubject);
		inquiryDTO.setInquiryType(inquiryType);
		inquiryDTO.setMemNo(memDTO.getMemNo());
		
		InquiryDAO inquiryDAO = new InquiryDAO();
		inquiryDAO.inquiryInsert(inquiryDTO);
		
	}
}
