package controller.user;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import model.DAO.AnnounceDAO;
import model.DTO.AnnounceDTO;

public class AnnounceWriteController {
	public void execute(HttpServletRequest request) {
		String announceDate = request.getParameter("announceDate");
		String announceSubject = request.getParameter("announceSubject");
		String announceContent = request.getParameter("announceContent");
		
		Date date =null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		try {
		   date= sdf.parse(announceDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		AnnounceDTO announceDTO = new AnnounceDTO();
		announceDTO.setAnnounceContent(announceContent);
		announceDTO.setAnnounceDate(date);
		announceDTO.setAnnounceSubject(announceSubject);
		
		AnnounceDAO announceDAO = new AnnounceDAO();
		announceDAO.annInsert(announceDTO);
	}
}
