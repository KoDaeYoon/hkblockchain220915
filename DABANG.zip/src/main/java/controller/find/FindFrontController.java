package controller.find;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.member.MemberJoinController;
import controller.user.UserWriteController;

public class FindFrontController extends HttpServlet implements Servlet{
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		
	if(command.equals("/findId.find")) {
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("view/findId.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/findIdok.find")) {
		FindIdController action = new FindIdController();
		action.execute(request);
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("view/findidAfter.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/findPw.find")) {
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("view/findPw.jsp");
		dispatcher.forward(request, response);
	}else if(command.equals("/findPwok.find")){
		FindPwController action = new FindPwController();
		action.execute(request);
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("view/findPwAfter.jsp");
		dispatcher.forward(request, response);
	}
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		doProcess(req, resp);
	}@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		doProcess(req, resp);
	}
	
}
	


