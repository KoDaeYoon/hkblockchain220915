package controller.find;

import javax.servlet.http.HttpServletRequest;

import model.DAO.MemberDAO;
import model.DTO.MemberDTO;


public class FindIdController<memId> {
	public void execute(HttpServletRequest request) {
		
		
		MemberDAO dao = new  MemberDAO();
		String memEmail = request.getParameter("memEmail");
		String memTel= request.getParameter("memTel");
		String id = dao.findidselectOne(memEmail, memTel);
		System.out.println(memEmail);
		request.setAttribute("id", id);
		
		}
		
		
		
	
    }

	
//		MemberDTO = dao.findidselectOne(memEmail, memTel);
//		
//		 if(memId != null) {//결과가 있으면(정보가 맞다면)
//	            response.sendRedirect("findidAfter.jsp?memId="+ memId);
//	            
//	            request.getSession().setAttribute("memId", memId);
//	            response.sendRedirect("findidAfter.jsp");
//	       }
//	     else {//결과가 없으면(정보가 맞지 않으면)
//	        	 response.sendRedirect("findidAfter.jsp?error");
//	         }

;