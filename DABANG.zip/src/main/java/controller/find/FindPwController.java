package controller.find;

import javax.servlet.http.HttpServletRequest;

import model.DAO.MemberDAO;

public class FindPwController<memPw> {
	public void execute(HttpServletRequest request) {
		
		MemberDAO dao = new MemberDAO();
		String memEmail = request.getParameter("memEmail");
		String memTel = request.getParameter("memTel");
		String pw = dao.findPwselectOne1(memEmail, memTel);
		request.setAttribute("pw", pw);
	}
}
