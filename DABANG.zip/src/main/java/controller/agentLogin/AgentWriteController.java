package controller.agentLogin;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import model.DAO.AgentDAO;
import model.DTO.AgentDTO;

public class AgentWriteController {
	public void execute(HttpServletRequest request) {
		
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String agentNo = request.getParameter("agentNo");
		String corporateNo = request.getParameter("corporateNo");
		String agentName = request.getParameter("agentName");
		String agentAddr = request.getParameter("agentAddr");
		String agentTel = request.getParameter("agentTel");
		String agentEmail= request.getParameter("agentEmail");
		String agentId = request.getParameter("agentId");
		String agentPw = request.getParameter("agentPw");
		
		AgentDTO agent = new AgentDTO();
		agent.setAgentAddr(agentAddr);
		agent.setAgentEmail(agentEmail);
		agent.setAgentName(agentName);
		agent.setAgentNo(agentNo);
		agent.setAgentTel(agentTel);
		agent.setCorporateNo(corporateNo);
		agent.setAgentId(agentId);
		agent.setAgentPw(agentPw);
		
		AgentDAO dao = new AgentDAO();
		dao.agentInsert(agent);
	}

}
