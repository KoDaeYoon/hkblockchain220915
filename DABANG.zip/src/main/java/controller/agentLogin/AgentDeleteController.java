package controller.agentLogin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.DAO.AgentDAO;
import model.DTO.AgentDTO;
import model.DTO.AuthInfo1DTO;

public class AgentDeleteController {
	public void execute(HttpServletRequest request) {
	
		HttpSession session = request.getSession();
		AuthInfo1DTO authInfo = (AuthInfo1DTO) session.getAttribute("dto11");
		String agentId = authInfo.getUserId();
		
		AgentDAO dao = new AgentDAO();
	     dao.agentDelete(agentId);
		
	}

}
