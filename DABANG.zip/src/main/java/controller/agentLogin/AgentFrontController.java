package controller.agentLogin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.login.UserLoginController;
import controller.user.UserWriteController;

public class AgentFrontController extends HttpServlet implements Servlet {
	protected void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());

		if (command.equals("/Agree.agent")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("agent/agree.jsp");
			dispatcher.forward(request, response);
		} else if (command.equals("/agreeWrite.agent")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("agent/agentForm.jsp");
			dispatcher.forward(request, response);
		} else if (command.equals("/agentRegist.agent")) {
			AgentWriteController action = new AgentWriteController();
			action.execute(request);
			response.sendRedirect("main.jsp");
		} else if (command.equals("/agentMyPage.agent")) {
			AgentDetailController action = new AgentDetailController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("agentMyPage.jsp");
			dispatcher.forward(request, response);
		} else if (command.equals("/agentUpdate.agent")) {
			AgentDetailController action = new AgentDetailController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("agent/agentModify.jsp");
			dispatcher.forward(request, response);
		} else if (command.equals("/agentModify.agent")) {
			AgentUpdateController action = new AgentUpdateController();
			action.execute(request);
			response.sendRedirect("agentMyPage.jsp");
		}else if (command.equals("/agentDelete.agent")) {
			AgentDeleteController action = new AgentDeleteController();
			action.execute(request);
			Cookie cookie = new Cookie("autoLogin", "");
			cookie.setPath("/");
			cookie.setMaxAge(0);
			response.addCookie(cookie);
			HttpSession session = request.getSession();
			session.invalidate();
			response.sendRedirect(request.getContextPath() + "/");
		} else if (command.equals("/agentMain.agent")) {
			AgentListController action = new AgentListController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("agent/agentList.jsp");
			dispatcher.forward(request, response);
		} else if (command.equals("/agentDetail.agent")) {
			AgentDetailController action = new AgentDetailController();
			action.execute(request);
			response.sendRedirect("agent/agentDetail.jsp");
		} else if (command.equals("/agentIdChk.agent")) {
			IdCheckController action = new IdCheckController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("agent/idCheckForm.jsp");
			dispatcher.forward(request, response);
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req, resp);
	}

}
