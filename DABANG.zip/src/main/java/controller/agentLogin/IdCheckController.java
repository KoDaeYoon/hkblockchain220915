package controller.agentLogin;

import javax.servlet.http.HttpServletRequest;

import model.DAO.AgentDAO;
import model.DTO.AgentDTO;

public class IdCheckController {
	public void execute(HttpServletRequest request) {
		
		String agentId = request.getParameter("agentId");
		AgentDAO dao = new AgentDAO();
		AgentDTO dto = dao.idchkselectOne(agentId);
		System.out.println("디티오 : "+dto);
		//.System.out.println("rs : "+dao.idchkselectOne());
		request.setAttribute("dto", dto);
		
	}

}
