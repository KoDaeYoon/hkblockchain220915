package controller.agentLogin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import model.DAO.AgentDAO;
import model.DTO.AgentDTO;

public class AgentListController {
	public void execute(HttpServletRequest request) {
		//String agentNo = request.getParameter("agentNo");
		AgentDAO dao = new AgentDAO();
		List<AgentDTO> list = dao.selectAll();
		request.setAttribute("list", list);
	}

}
