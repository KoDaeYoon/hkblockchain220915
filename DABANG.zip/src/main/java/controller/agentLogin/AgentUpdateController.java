package controller.agentLogin;

import javax.servlet.http.HttpServletRequest;

import model.DAO.AgentDAO;
import model.DTO.AgentDTO;

public class AgentUpdateController {
	public void execute(HttpServletRequest request) {
		String agentAddr = request.getParameter("agentAddr");
		String agentEmail = request.getParameter("agentEmail");
		String agentTel = request.getParameter("agentTel");
		String agentName = request.getParameter("agentName");

		AgentDTO dto = new AgentDTO();
		dto.setAgentAddr(agentAddr);
		dto.setAgentEmail(agentEmail);
		dto.setAgentName(agentName);
		dto.setAgentTel(agentTel);

		AgentDAO dao = new AgentDAO();
		dao.agentUpdate(dto);
		request.setAttribute("dto", dao);
	}
}
