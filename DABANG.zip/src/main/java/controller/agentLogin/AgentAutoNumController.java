package controller.agentLogin;

import javax.servlet.http.HttpServletRequest;

import model.DAO.AgentDAO;

public class AgentAutoNumController {
	public void execute(HttpServletRequest request) {
		AgentDAO dao = new AgentDAO();
		String agentNo = dao.agentAutoNum();
		request.setAttribute("agentNo", agentNo);
	}
}
