package controller.realestate;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import model.DAO.EstateDAO;
import model.DTO.EstateDTO;

public class EstateListController {
	public void execute(HttpServletRequest request) {
		String findEstate = request.getParameter("findEstate");
		EstateDAO dao = new EstateDAO();
		List<EstateDTO> estateList = dao.findEstate(findEstate);
		request.setAttribute("estateList", estateList);
		request.setAttribute("findEstate", findEstate);
		System.out.println(estateList);
		System.out.println(findEstate);
	}
}
