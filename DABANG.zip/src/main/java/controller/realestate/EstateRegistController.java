package controller.realestate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.DAO.EstateDAO;
import model.DAO.UserDAO;
import model.DTO.AuthInfo1DTO;
import model.DTO.EstateDTO;
import model.DTO.MemberDTO;

public class EstateRegistController {
	public void execute(HttpServletRequest request) {
		String realNo = request.getParameter("realNo");
		String realName = request.getParameter("realName");
		String realAddr = request.getParameter("realAddr");
		String realPrice = request.getParameter("realPrice");
		String mediationPay = request.getParameter("mediationPay");
		String option1 = request.getParameter("option1");
		String securityFacil = request.getParameter("securityFacil");
		String surroundFacil = request.getParameter("surroundFacil");
		String realInform = request.getParameter("realInform");
		String administrationCost = request.getParameter("administrationCost");
		String productType = request.getParameter("productType");
		String productPhoto = request.getParameter("productPhoto");
		String untactContract = request.getParameter("untactContract");
		String useApproveDate = request.getParameter("useApproveDate");
		String registrationDate = request.getParameter("registrationDate");
		
		Date appDate = null;
		Date regiDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		try {
			appDate = sdf.parse(useApproveDate);
			regiDate = sdf.parse(registrationDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		HttpSession session = request.getSession();
	    AuthInfo1DTO authInfo = (AuthInfo1DTO) session.getAttribute("dto11");
	    String memId = authInfo.getUserId();
	    UserDAO userDAO = new UserDAO();
	      
	    MemberDTO userDTO = userDAO.userOne(memId);
	    
		EstateDTO estDTO = new EstateDTO();
		estDTO.setAdministrationCost(administrationCost);
		estDTO.setMediationPay(mediationPay);
		estDTO.setOption1(option1);
		estDTO.setProductPhoto(productPhoto);
		estDTO.setProductType(productType);
		estDTO.setRealAddr(realAddr);
		estDTO.setRealInform(realInform);
		estDTO.setRealName(realName);
		estDTO.setRealNo(realNo);
		estDTO.setRealPrice(realPrice);
		estDTO.setRegistrationDate(regiDate);
		estDTO.setSecurityFacil(securityFacil);
		estDTO.setSurroundFacil(surroundFacil);
		estDTO.setUntactContract(untactContract);
		estDTO.setUseApproveDate(appDate);
		estDTO.setMemNo(userDTO.getMemNo());
		
		EstateDAO dao = new EstateDAO();
		dao.estRegist(estDTO);
	}
}
