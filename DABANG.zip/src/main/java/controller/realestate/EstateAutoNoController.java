package controller.realestate;

import javax.servlet.http.HttpServletRequest;

import model.DAO.EstateDAO;

public class EstateAutoNoController {
	public void execute(HttpServletRequest request) {
		EstateDAO dao = new EstateDAO();
		String realNo = dao.autoEstNo();
		request.setAttribute("realNo", realNo);
	}
}
