package controller.realestate;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import model.DAO.EstateDAO;
import model.DTO.EstateDTO;

public class EstateCookieController {
	public void execute(HttpServletRequest request) {
		EstateDAO dao = new EstateDAO();
		/**
		 * 쿠키값 전달
		 */
		List<String> realNos = new ArrayList<String>();
		Cookie[] cookies = request.getCookies();
		if(cookies != null && cookies.length > 0){
			for(Cookie cookie: cookies){
				System.out.println("쿠키이름 :"+cookie.getName());
				System.out.println("쿠키값 :"+cookie.getValue());
				if((cookie.getName()).startsWith("est_")){
					realNos.add(cookie.getValue());
					
				}
			}
		}System.out.println("^^^"+realNos);
		List<EstateDTO> list = new ArrayList<>();
		for(String realNo : realNos){
			EstateDTO estDTO = dao.estateOne(realNo);
			list.add(estDTO);
		}
		System.out.println(list);
		
		request.setAttribute("list", list);
		request.setAttribute("realNos", realNos);

	}
}
