package controller.realestate;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EstateFrontController extends HttpServlet implements Servlet{
	protected void doPro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		if(command.equals("/estateList.est")) {
			EstateListController action = new EstateListController();
			action.execute(request);
			EstateCookieController cookieReq = new EstateCookieController();
			cookieReq.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateList.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/estateRegist.est")) {
			EstateAutoNoController action = new EstateAutoNoController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateRegist.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/estateUpload.est")) {
			EstateRegistController action = new EstateRegistController();
			action.execute(request);
			response.sendRedirect("estateList.est");
		}else if(command.equals("/estateInfo.est")) {
			EstateInfoController action = new EstateInfoController();
			action.execute(request, response);
			EstateListController action1 = new EstateListController();
			action1.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateInfo.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/estateModify.est")) {
			EstateInfoController action = new EstateInfoController();
			action.execute(request, response);
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateUpdate.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/estateUpdate.est")) {
			EstateUpdateController action = new EstateUpdateController();
			action.execute(request);
			response.sendRedirect("estateInfo.est");
		}else if(command.equals("/estateDel.est")) {
			EstateDelController action = new EstateDelController();
			action.execute(request);
			response.sendRedirect("estateList.est");
		}else if(command.equals("/estateSelectDate.est")) {
			EstateListController action = new EstateListController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateSelectDate.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/estateContract.est")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateContract.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/estateContractTwo.est")) {
			EstateListController action = new EstateListController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateContractTwo.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/contractRequest.est")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/contractRequest.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/estateViewTel.est")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateViewTel.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/estateViewTel2.est")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateViewTel2.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/estateViewTel3.est")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("realestate/estateViewTel3.jsp");
			dispatcher.forward(request, response);
		}
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPro(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPro(req, resp);
	}
}
