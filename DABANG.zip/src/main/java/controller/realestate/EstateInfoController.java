package controller.realestate;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.DAO.EstateDAO;
import model.DAO.UserDAO;
import model.DTO.AuthInfo1DTO;
import model.DTO.EstateDTO;
import model.DTO.MemberDTO;

public class EstateInfoController {
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		String realNo = request.getParameter("realNo");
		EstateDAO dao = new EstateDAO();
		EstateDTO estDTO = dao.estateOne(realNo);
		
		HttpSession session = request.getSession();
	    AuthInfo1DTO authInfo = (AuthInfo1DTO) session.getAttribute("dto11");
	    MemberDTO userDTO = new MemberDTO();
	    if(authInfo != null) {
	       String memId = authInfo.getUserId();
	       UserDAO userDAO = new UserDAO();
	       userDTO = userDAO.userOne(memId);
	     }
		
		//쿠키생성
		Cookie cookie = new Cookie(realNo, estDTO.getRealNo());
		cookie.setPath("/");
		cookie.setMaxAge(60*60*24);
		response.addCookie(cookie);
		System.out.println("쿠키 : "+cookie);
		
		
		request.setAttribute("userDTO", userDTO);
		request.setAttribute("estDTO", estDTO);
	}
}
