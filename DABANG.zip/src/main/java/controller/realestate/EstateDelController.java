package controller.realestate;

import javax.servlet.http.HttpServletRequest;

import model.DAO.EstateDAO;

public class EstateDelController {
	public void execute(HttpServletRequest request) {
		String realNo = request.getParameter("realNo");
		EstateDAO dao = new EstateDAO();
		dao.estateDel(realNo);
	}
}
