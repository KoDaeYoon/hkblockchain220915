package controller.employee;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import model.DAO.EmpDAO;
import model.DTO.EmpDTO;

public class EmployeeListController {
	public void execute(HttpServletRequest request) {
		String empNo = request.getParameter("empNo");
		EmpDAO empDAO = new EmpDAO();
		List<EmpDTO> list = empDAO.selectAll();
		request.setAttribute("list", list);
	}
}
