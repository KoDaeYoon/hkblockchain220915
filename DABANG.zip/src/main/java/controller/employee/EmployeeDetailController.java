package controller.employee;

import javax.servlet.http.HttpServletRequest;

import model.DAO.EmpDAO;
import model.DTO.EmpDTO;

public class EmployeeDetailController {
	public void execute(HttpServletRequest request) {
		String empNo = request.getParameter("empNo");
		EmpDAO empDAO = new EmpDAO();
		EmpDTO dto = empDAO.selectOne(empNo);
		request.setAttribute("dto", dto);
	}
}
