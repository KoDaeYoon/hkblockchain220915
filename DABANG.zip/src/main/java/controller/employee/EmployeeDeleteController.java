package controller.employee;

import javax.servlet.http.HttpServletRequest;

import model.DAO.EmpDAO;

public class EmployeeDeleteController {
	public void execute(HttpServletRequest request) {
		String empNo = request.getParameter("empNo");
		EmpDAO empDAO = new EmpDAO();
		empDAO.employeeDelete(empNo);
	}
}
