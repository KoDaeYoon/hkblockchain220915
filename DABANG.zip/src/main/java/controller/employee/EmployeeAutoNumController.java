package controller.employee;

import javax.servlet.http.HttpServletRequest;

import model.DAO.EmpDAO;

public class EmployeeAutoNumController {
	public void execute(HttpServletRequest request) {
		EmpDAO dao = new EmpDAO();
		String empNo = dao.empAutoNum();
		request.setAttribute("empNo", empNo);
	}
}