package controller.employee;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import model.DAO.EmpDAO;
import model.DTO.EmpDTO;

public class EmployeeModifyController {
	public void execute(HttpServletRequest request) {
		String empNo = request.getParameter("empNo");
		String empPw = request.getParameter("empPw");
		String empFirstName = request.getParameter("empFirstName");
		String empLastName = request.getParameter("empLastName");
		String empGender = request.getParameter("empGender");
		String empPhone = request.getParameter("empPhone");
		String empBirth = request.getParameter("empBirth");
		String empSal = request.getParameter("empSal");
		String empHireDate = request.getParameter("empHireDate");
		String empDepartmentName = request.getParameter("empDepartmentName");
		String empJobTitle = request.getParameter("empJobTitle");
		String empAddr = request.getParameter("empAddr");
		String empAddrDetail = request.getParameter("empAddrDetail");
		String empPostCode = request.getParameter("empPostCode");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		Date date1 = null;
		Date date2 = null;
		try {
			date1 = sdf.parse(empBirth);
			date2 = sdf.parse(empHireDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		EmpDTO dto = new EmpDTO();
		dto.setEmpAddr(empAddr);
		dto.setEmpBirth(date1);
		dto.setEmpDepartmentName(empDepartmentName);
		dto.setEmpFirstName(empFirstName);
		dto.setEmpGender(empGender);
		dto.setEmpHireDate(date2);
		dto.setEmpJobTitle(empJobTitle);
		dto.setEmpLastName(empLastName);
		dto.setEmpNo(empNo);
		dto.setEmpPhone(empPhone);
		dto.setEmpPw(empPw);
		dto.setEmpSal(Long.parseLong(empSal));
		dto.setEmpAddrDetail(empAddrDetail);
		dto.setEmpPostCode(empPostCode);
		
		EmpDAO empDAO = new EmpDAO();
		empDAO.employeeUpdate(dto);
		
	}
}
