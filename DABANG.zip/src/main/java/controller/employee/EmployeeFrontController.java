package controller.employee;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class EmployeeFrontController extends HttpServlet implements javax.servlet.Servlet{
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		if(command.equals("/employeeList.emp")) {
			EmployeeListController action = new EmployeeListController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("employee/employeeList.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/employeeRegist.emp")) {
			EmployeeAutoNumController action = new EmployeeAutoNumController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("employee/employeeForm.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/employeeWrite.emp")) {
			EmployeeWriteController action = new EmployeeWriteController();
			action.execute(request);
			response.sendRedirect("employeeList.emp");
		}else if(command.equals("/employeeDetail.emp")) {
			EmployeeDetailController action = new EmployeeDetailController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("employee/employeeDetail.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/employeeUpdate.emp")) {
			EmployeeDetailController action = new EmployeeDetailController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("employee/employeeModify.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/employeeModify.emp")) {
			EmployeeModifyController action = new EmployeeModifyController();
			action.execute(request);
			response.sendRedirect("employeeDetail.emp?empNo="+request.getParameter("empNo"));
		}else if(command.equals("/employeeDelete.emp")) {
			EmployeeDeleteController action = new EmployeeDeleteController();
			action.execute(request);
			response.sendRedirect("employeeList.emp");
		}
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
}
