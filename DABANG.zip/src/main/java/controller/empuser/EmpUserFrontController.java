package controller.empuser;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EmpUserFrontController extends HttpServlet implements javax.servlet.Servlet{
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		if(command.equals("/empMyPage.naver")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("empMyPage/empMyPage.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/empInfo.naver")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("empMyPage/empPwCon.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/empUpdate.naver")) {
			EmpDetailController action = new EmpDetailController();
			action.execute(request);
			RequestDispatcher dispatcher = request.getRequestDispatcher("empMyPage/empModify.jsp");
			dispatcher.forward(request, response);
		}else if(command.equals("/empModify.naver")) {
			EmpModifyController action = new EmpModifyController();
			action.execute(request);
			response.sendRedirect("empMyPage.naver");
		}else if(command.equals("/empPwCon.naver")) {
			EmpPasswordConController action = new EmpPasswordConController();
			String ck = action.execute(request);
			EmpDetailController action1 = new EmpDetailController();
			action1.execute(request);
			if(ck != null) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("empMyPage/empDetail.jsp");
				dispatcher.forward(request, response);
			}else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("empMyPage/empPwCon.jsp");
				dispatcher.forward(request, response);
			}
		}
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
}
