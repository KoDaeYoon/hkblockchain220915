package controller.empuser;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.DAO.EmpDAO;
import model.DTO.AuthInfo1DTO;

public class EmpPasswordConController {
	public String execute(HttpServletRequest request) {
		String employeePw = request.getParameter("employeePw");
		HttpSession session = request.getSession();
		AuthInfo1DTO authInfo = (AuthInfo1DTO)session.getAttribute("dto11");
		String empNo = authInfo.getUserId();
		EmpDAO empDAO = new EmpDAO();
		String ck= empDAO.empPwCk(empNo, employeePw);
		return ck;
	}
}
