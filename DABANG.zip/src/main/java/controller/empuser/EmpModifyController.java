package controller.empuser;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.DAO.EmpDAO;
import model.DTO.AuthInfo1DTO;
import model.DTO.EmpDTO;

public class EmpModifyController {
	public void execute(HttpServletRequest request) {
		HttpSession session = request.getSession();
		AuthInfo1DTO authInfo = (AuthInfo1DTO)session.getAttribute("dto11");
		String empNo = authInfo.getUserId();
		String empPw= request.getParameter("empPw");
		String empPhone= request.getParameter("empPhone");
		String empSal= request.getParameter("empSal");
		String empHireDate= request.getParameter("empHireDate");
		String empDepartmentName= request.getParameter("empDepartmentName");
		String empJobTitle= request.getParameter("empJobTitle");
		String empAddr= request.getParameter("empAddr");
		String empAddrDetail= request.getParameter("empAddrDetail");
		String empPostCode= request.getParameter("empPostCode");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		Date date = null;
		try {
			date = sdf.parse(empHireDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		EmpDTO dto = new EmpDTO();
		dto.setEmpNo(empNo);
		dto.setEmpPw(empPw);
		dto.setEmpPhone(empPhone);
		dto.setEmpSal(Long.parseLong(empSal));
		dto.setEmpHireDate(date);
		dto.setEmpDepartmentName(empDepartmentName);
		dto.setEmpJobTitle(empJobTitle);
		dto.setEmpAddr(empAddr);
		dto.setEmpAddrDetail(empAddrDetail);
		dto.setEmpPostCode(empPostCode);
		
		EmpDAO empDAO = new EmpDAO();
		empDAO.empUpdate(dto);
		
	}
}
