package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.DTO.MemberDTO;

public class MemberDAO {
	String jdbcURL;
	String jdbcDriver;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String sql;
	public MemberDAO() {
		jdbcDriver = "oracle.jdbc.driver.OracleDriver";
		jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	}
	public Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName(jdbcDriver);
			conn = DriverManager.getConnection(jdbcURL, "hkk123", "oracle");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	public String findPwselectOne1(String memEmail, String memTel) {
		String pw = null;
		con = getConnection();
		sql = " select MEM_PW from member where MEM_EMAIL = ? and MEM_TEL= ?";
		
	try {
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, memEmail);
		pstmt.setString(2, memTel);
		rs = pstmt.executeQuery();
		if(rs.next()) {
			pw = rs.getString("MEM_PW");
	}
	} catch (SQLException e) {
			e.printStackTrace();
	}
	return pw;
	}
	public String findidselectOne(String memEmail,String memTel) {
         String id =null;
		con = getConnection();
		sql = " select MEM_ID  from member where MEM_EMAIL = ? and MEM_TEL=?";
	try {
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, memEmail);
		pstmt.setString(2, memTel);
		rs = pstmt.executeQuery();
	    if(rs.next()) {
	    	id= rs.getString("MEM_ID");
	}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return id;
	}
	public void memDel(String memNo) {
		con = getConnection();
		sql = "delete from member where mem_no = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memNo);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public MemberDTO memberOne(String memNo) {
		MemberDTO memDTO = null;
		con = getConnection();
		sql = "select MEM_NO,FIRST_NAME,LAST_NAME,MEM_ID,MEM_PW,MEM_BIRTH,MEM_GENDER,"
				+ "MEM_TEL,MEM_EMAIL from member where mem_no = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memNo);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				memDTO = new MemberDTO();
				memDTO.setFirstName(rs.getString("FIRST_NAME"));
				memDTO.setLastName(rs.getString("LAST_NAME"));
				memDTO.setMemBirth(rs.getDate("MEM_BIRTH"));
				memDTO.setMemEmail(rs.getString("MEM_EMAIL"));
				memDTO.setMemGender(rs.getString("MEM_GENDER"));
				memDTO.setMemId(rs.getString("MEM_ID"));
				memDTO.setMemNo(rs.getString("MEM_NO"));
				memDTO.setMemPw(rs.getString("MEM_PW"));
				memDTO.setMemTel(rs.getString("MEM_TEL"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return memDTO;
	}
	public void memUpdate(MemberDTO memDTO) {
		con = getConnection();
		sql = "update member set FIRST_NAME = ?, LAST_NAME = ?,MEM_ID = ?, MEM_PW = ?, MEM_BIRTH = ?, MEM_GENDER = ?, MEM_TEL = ?, MEM_EMAIL = ? where mem_no = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memDTO.getFirstName());
			pstmt.setString(2, memDTO.getLastName());
			pstmt.setString(3, memDTO.getMemId());
			pstmt.setString(4, memDTO.getMemPw());
			pstmt.setDate(5, new java.sql.Date(memDTO.getMemBirth().getTime()));
			pstmt.setString(6, memDTO.getMemGender());
			pstmt.setString(7, memDTO.getMemTel());
			pstmt.setString(8, memDTO.getMemEmail());
			pstmt.setString(9, memDTO.getMemNo());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public List<MemberDTO> selectAll() {
		List<MemberDTO> list = new ArrayList<MemberDTO>();
		con = getConnection();
		sql = "select MEM_NO,FIRST_NAME,LAST_NAME,MEM_ID,MEM_PW,MEM_BIRTH,MEM_GENDER,MEM_TEL,MEM_EMAIL from member";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				MemberDTO memDTO = new MemberDTO();
				memDTO.setFirstName(rs.getString("FIRST_NAME"));
				memDTO.setLastName(rs.getString("LAST_NAME"));
				memDTO.setMemBirth(rs.getDate("MEM_BIRTH"));
				memDTO.setMemEmail(rs.getString("MEM_EMAIL"));
				memDTO.setMemGender(rs.getString("MEM_GENDER"));
				memDTO.setMemId(rs.getString("MEM_ID"));
				memDTO.setMemNo(rs.getString("MEM_NO"));
				memDTO.setMemPw(rs.getString("MEM_PW"));
				memDTO.setMemTel(rs.getString("MEM_TEL"));
				list.add(memDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public void memJoin(MemberDTO memDTO) {
		con = getConnection();
		sql = "insert into member(MEM_NO, FIRST_NAME, LAST_NAME, MEM_ID, MEM_PW, MEM_BIRTH, MEM_GENDER, MEM_TEL, MEM_EMAIL)"
				+ " values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memDTO.getMemNo());
			pstmt.setString(2, memDTO.getFirstName());
			pstmt.setString(3, memDTO.getLastName());
			pstmt.setString(4, memDTO.getMemId());
			pstmt.setString(5, memDTO.getMemPw());
			pstmt.setDate(6, new java.sql.Date(memDTO.getMemBirth().getTime()));
			pstmt.setString(7, memDTO.getMemGender());
			pstmt.setString(8, memDTO.getMemTel());
			pstmt.setString(9, memDTO.getMemEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
