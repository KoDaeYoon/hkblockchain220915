package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;

import model.DTO.EstateDTO;

public class EstateDAO {
	String jdbcURL;
	String jdbcDriver;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String sql;
	public EstateDAO() {
		jdbcDriver = "oracle.jdbc.driver.OracleDriver";
		jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	}
	public Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName(jdbcDriver);
			conn = DriverManager.getConnection(jdbcURL, "hkk123", "oracle");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	public String autoEstNo() {
		String realNo = null;
		con = getConnection();
		sql = "select est_seq.nextval from dual";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			realNo = "est_"+rs.getString("nextval");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return realNo;
	}
	public List<EstateDTO> findEstate(String findEstate){
		List<EstateDTO> estateList =  new ArrayList<EstateDTO>();
		con = getConnection();
		sql = "select REAL_NO,REAL_NAME,REAL_ADDR,REAL_PRICE,MEDIATION_PAY,OPTION1,SECURITY_FACIL,SURROUND_FACIL,REAL_INFORM,ADMINISTRATION_COST,PRODUCT_TYPE,PRODUCT_PHOTO,UNTACT_CONTRACT,USE_APPROVE_DATE,REGISTRATION_DATE"
				+ " from real_estate";
		
		if(findEstate != null && findEstate != "") {
				sql += " where REAL_ADDR like ?";
		}
		try {
			pstmt = con.prepareStatement(sql);
			if(findEstate != null && findEstate != "") {
				pstmt.setString(1, "%"+findEstate+"%");
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				EstateDTO estDTO = new EstateDTO();
				estDTO.setAdministrationCost(rs.getString("ADMINISTRATION_COST"));
				estDTO.setMediationPay(rs.getString("MEDIATION_PAY"));
				estDTO.setOption1(rs.getString("OPTION1"));
				estDTO.setProductPhoto(rs.getString("PRODUCT_PHOTO"));
				estDTO.setProductType(rs.getString("PRODUCT_TYPE"));
				estDTO.setRealAddr(rs.getString("REAL_ADDR"));
				estDTO.setRealInform(rs.getString("REAL_INFORM"));
				estDTO.setRealName(rs.getString("REAL_NAME"));
				estDTO.setRealNo(rs.getString("REAL_NO"));
				estDTO.setRealPrice(rs.getString("REAL_PRICE"));
				estDTO.setRegistrationDate(rs.getDate("REGISTRATION_DATE"));
				estDTO.setSecurityFacil(rs.getString("SECURITY_FACIL"));
				estDTO.setSurroundFacil(rs.getString("SURROUND_FACIL"));
				estDTO.setUntactContract(rs.getString("UNTACT_CONTRACT"));
				estDTO.setUseApproveDate(rs.getDate("USE_APPROVE_DATE"));
				estateList.add(estDTO);
			}
			System.out.println("------------------------------------------------------------------------");
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
		}
		return estateList;
	}
	public void estateDel(String realNo) {
		con = getConnection();
		sql = "delete from real_estate where real_no = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, realNo);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void estUpdate(EstateDTO estDTO) {
		con = getConnection();
		sql = "update real_estate set REAL_NAME = ?, REAL_ADDR = ?, REAL_PRICE = ?, MEDIATION_PAY = ?, OPTION1 = ?, SECURITY_FACIL = ?, SURROUND_FACIL = ?, REAL_INFORM = ?, ADMINISTRATION_COST = ?,"
				+ " PRODUCT_TYPE = ?,PRODUCT_PHOTO = ?, UNTACT_CONTRACT = ?, USE_APPROVE_DATE = ?, REGISTRATION_DATE = ? where REAL_NO = ?;";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, estDTO.getRealName());
			pstmt.setString(2, estDTO.getRealAddr());
			pstmt.setString(3, estDTO.getRealPrice());
			pstmt.setString(4, estDTO.getMediationPay());
			pstmt.setString(5, estDTO.getOption1());
			pstmt.setString(6, estDTO.getSecurityFacil());
			pstmt.setString(7, estDTO.getSurroundFacil());
			pstmt.setString(8, estDTO.getRealInform());
			pstmt.setString(9, estDTO.getAdministrationCost());
			pstmt.setString(10, estDTO.getProductType());
			pstmt.setString(11, estDTO.getProductPhoto());
			pstmt.setString(12, estDTO.getUntactContract());
			pstmt.setDate(13, new java.sql.Date(estDTO.getUseApproveDate().getTime()));
			pstmt.setDate(14, new java.sql.Date(estDTO.getRegistrationDate().getTime()));
			pstmt.setString(15, estDTO.getRealNo());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public EstateDTO estateOne(String realNo) {
		EstateDTO estDTO = null;
		con = getConnection();
		sql = "select REAL_NO,REAL_NAME,REAL_ADDR,REAL_PRICE,MEDIATION_PAY,OPTION1,SECURITY_FACIL,SURROUND_FACIL,REAL_INFORM,ADMINISTRATION_COST,PRODUCT_TYPE,PRODUCT_PHOTO,UNTACT_CONTRACT,USE_APPROVE_DATE,REGISTRATION_DATE, MEM_NO "
				+ " from real_estate"
				+ " where REAL_NO = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, realNo);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				estDTO = new EstateDTO();
				estDTO.setAdministrationCost(rs.getString("ADMINISTRATION_COST"));
				estDTO.setMediationPay(rs.getString("MEDIATION_PAY"));
				estDTO.setOption1(rs.getString("OPTION1"));
				estDTO.setProductPhoto(rs.getString("PRODUCT_PHOTO"));
				estDTO.setProductType(rs.getString("PRODUCT_TYPE"));
				estDTO.setRealAddr(rs.getString("REAL_ADDR"));
				estDTO.setRealInform(rs.getString("REAL_INFORM"));
				estDTO.setRealName(rs.getString("REAL_NAME"));
				estDTO.setRealNo(rs.getString("REAL_NO"));
				estDTO.setRealPrice(rs.getString("REAL_PRICE"));
				estDTO.setRegistrationDate(rs.getDate("REGISTRATION_DATE"));
				estDTO.setSecurityFacil(rs.getString("SECURITY_FACIL"));
				estDTO.setSurroundFacil(rs.getString("SURROUND_FACIL"));
				estDTO.setUntactContract(rs.getString("UNTACT_CONTRACT"));
				estDTO.setUseApproveDate(rs.getDate("USE_APPROVE_DATE"));
				estDTO.setMemNo(rs.getString("MEM_NO"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return estDTO;
	}
	public void estRegist(EstateDTO estDTO) {
		con = getConnection();
		sql = "insert into real_estate(REAL_NO, REAL_NAME, REAL_ADDR, REAL_PRICE, MEDIATION_PAY, OPTION1, SECURITY_FACIL,"
				+ " SURROUND_FACIL, REAL_INFORM, ADMINISTRATION_COST, PRODUCT_TYPE, PRODUCT_PHOTO, UNTACT_CONTRACT, USE_APPROVE_DATE, REGISTRATION_DATE, MEM_NO)"
				+ " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, estDTO.getRealNo());
			pstmt.setString(2, estDTO.getRealName());
			pstmt.setString(3, estDTO.getRealAddr());
			pstmt.setString(4, estDTO.getRealPrice());
			pstmt.setString(5, estDTO.getMediationPay());
			pstmt.setString(6, estDTO.getOption1());
			pstmt.setString(7, estDTO.getSecurityFacil());
			pstmt.setString(8, estDTO.getSurroundFacil());
			pstmt.setString(9, estDTO.getRealInform());
			pstmt.setString(10, estDTO.getAdministrationCost());
			pstmt.setString(11, estDTO.getProductType());
			pstmt.setString(12, estDTO.getProductPhoto());
			pstmt.setString(13, estDTO.getUntactContract());
			pstmt.setDate(14, new java.sql.Date(estDTO.getUseApproveDate().getTime()));
			pstmt.setDate(15, new java.sql.Date(estDTO.getRegistrationDate().getTime()));
			pstmt.setString(16, estDTO.getMemNo());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
