package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.DTO.InquiryDTO;

public class InquiryDAO {
	String jdbcURL;
	String jdbcDriver;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String sql;
	public InquiryDAO() {
		jdbcDriver = "oracle.jdbc.driver.OracleDriver";
		jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	}
	public Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName(jdbcDriver);
			conn = DriverManager.getConnection(jdbcURL, "hkk123", "oracle");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	public List<InquiryDTO> inquirySelectAll(){
		List<InquiryDTO> list = new ArrayList<InquiryDTO>();
		con = getConnection();
		sql = " select inquiry_date, inquiry_type, inquiry_subject, inquiry_content, inquiry_image1,inquiry_image2,inquiry_image3, "
				+ "  answer_reply, emp_no, answer_date "
				+ " from inquiry "
				+ " order by inquiry_date desc ";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				InquiryDTO inquiryDTO = new InquiryDTO();
				inquiryDTO.setInquiryContent(rs.getString("inquiry_content"));
				inquiryDTO.setInquiryDate(rs.getDate("inquiry_date"));
				inquiryDTO.setInquiryImage1(rs.getString("inquiry_image1"));
				inquiryDTO.setInquiryImage2(rs.getString("inquiry_image2"));
				inquiryDTO.setInquiryImage3(rs.getString("inquiry_image3"));
				inquiryDTO.setInquirySubject(rs.getString("inquiry_subject"));
				inquiryDTO.setInquiryType(rs.getString("inquiry_type"));
				inquiryDTO.setAnswerDate(rs.getString("answer_date"));
				inquiryDTO.setAnswerReply(rs.getString("answer_reply"));
				inquiryDTO.setEmpNo(rs.getString("emp_no"));
				list.add(inquiryDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public void inquiryReplyUpdate(String inquirySubject, String answerReply, String empNo) {
		con = getConnection();
		sql = " update inquiry "
				+ " set answer_reply = ?, "
				+ " emp_no = ?, "
				+ " answer_date = sysdate "
				+ " where inquiry_subject = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, answerReply);
			pstmt.setString(2, empNo);
			pstmt.setString(3, inquirySubject);
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 수정되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void inquiryDelete(String inquirySubject) {
		con = getConnection();
		sql = " delete from inquiry where inquiry_subject = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, inquirySubject);
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 삭제되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void inquiryUpdate(InquiryDTO inquiryDTO) {
		con = getConnection();
		sql = " update inquiry "
				+ " set inquiry_type = ?, "
				+ " inquiry_content = ? "
				+ " where inquiry_subject = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, inquiryDTO.getInquiryType());
			pstmt.setString(2, inquiryDTO.getInquiryContent());
			pstmt.setString(3, inquiryDTO.getInquirySubject());
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 수정되었습니다.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void inquiryDeleteEmp(String inquirySubject) {
		con = getConnection();
		sql = " delete from inquiry where inquiry_subject = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, inquirySubject);
			int i = pstmt.executeUpdate();
			System.out.println(i +"개가 삭제되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public InquiryDTO selectOne(String inquirySubject) {
		InquiryDTO inquiryDTO = null;
		con = getConnection();
		sql = " select inquiry_date, inquiry_type, inquiry_subject, inquiry_content, inquiry_image1,inquiry_image2,inquiry_image3, "
				+ " answer_reply, emp_no, answer_date "
				+ " from inquiry "
				+ " where inquiry_subject = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, inquirySubject);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				inquiryDTO = new InquiryDTO();
				inquiryDTO.setInquiryContent(rs.getString("inquiry_content"));
				inquiryDTO.setInquiryDate(rs.getDate("inquiry_date"));
				inquiryDTO.setInquiryImage1(rs.getString("inquiry_image1"));
				inquiryDTO.setInquiryImage2(rs.getString("inquiry_image2"));
				inquiryDTO.setInquiryImage3(rs.getString("inquiry_image3"));
				inquiryDTO.setInquirySubject(rs.getString("inquiry_subject"));
				inquiryDTO.setInquiryType(rs.getString("inquiry_type"));
				inquiryDTO.setAnswerDate(rs.getString("answer_date"));
				inquiryDTO.setAnswerReply(rs.getString("answer_reply"));
				inquiryDTO.setEmpNo(rs.getString("emp_no"));
				//inquiryDTO.setInquiryNo(rs.getString("inquiry_no"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return inquiryDTO;
	}
	public List<InquiryDTO> selectAll() {
		List<InquiryDTO> list = new ArrayList<InquiryDTO>();
		con = getConnection();	
		sql = " select inquiry_date, inquiry_type, inquiry_subject, inquiry_content, inquiry_image1,inquiry_image2,inquiry_image3, "
				+ "  answer_reply, emp_no, answer_date, inquiry_no, mem_no "
				+ " from inquiry "
				+ " order by inquiry_date desc ";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				InquiryDTO inquiryDTO = new InquiryDTO();
				inquiryDTO.setInquiryContent(rs.getString("inquiry_content"));
				inquiryDTO.setInquiryDate(rs.getDate("inquiry_date"));
				inquiryDTO.setInquiryImage1(rs.getString("inquiry_image1"));
				inquiryDTO.setInquiryImage2(rs.getString("inquiry_image2"));
				inquiryDTO.setInquiryImage3(rs.getString("inquiry_image3"));
				inquiryDTO.setInquirySubject(rs.getString("inquiry_subject"));
				inquiryDTO.setInquiryType(rs.getString("inquiry_type"));
				inquiryDTO.setAnswerDate(rs.getString("answer_date"));
				inquiryDTO.setAnswerReply(rs.getString("answer_reply"));
				inquiryDTO.setEmpNo(rs.getString("emp_no"));
				inquiryDTO.setInquiryNo(rs.getString("inquiry_no"));
				inquiryDTO.setMemNo(rs.getString("mem_no"));
				list.add(inquiryDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}
	public void inquiryInsert(InquiryDTO inquiryDTO) {
		con = getConnection();
		sql = " insert into inquiry(inquiry_date, inquiry_type, inquiry_subject, inquiry_content, inquiry_image1,inquiry_image2,inquiry_image3,"
				+ "  answer_reply, emp_no, answer_date, inquiry_no, mem_no ) "
				+ " values(sysdate, ?,?,?,?,?,?,null,null, null, ?,?) ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, inquiryDTO.getInquiryType());
			pstmt.setString(2, inquiryDTO.getInquirySubject());
			pstmt.setString(3, inquiryDTO.getInquiryContent());
			pstmt.setString(4, inquiryDTO.getInquiryImage1());
			pstmt.setString(5, inquiryDTO.getInquiryImage2());
			pstmt.setString(6, inquiryDTO.getInquiryImage3());
			pstmt.setString(7, inquiryDTO.getInquiryNo());
			pstmt.setString(8, inquiryDTO.getMemNo());
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 삽입되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
}
