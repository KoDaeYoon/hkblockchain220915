package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.DTO.AnnounceDTO;

public class AnnounceDAO {
	String jdbcURL;
	String jdbcDriver;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String sql;
	public AnnounceDAO() {
		jdbcDriver = "oracle.jdbc.driver.OracleDriver";
		jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	}
	public Connection getConnection() {
		Connection conn= null;
		try {
			Class.forName(jdbcDriver);
			conn = DriverManager.getConnection(jdbcURL,"hkk123","oracle");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	public void annDelete(String announceSubject) {
		con = getConnection();
		sql = " delete from announcement where announce_subject = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, announceSubject);
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 삭제되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void annUpdate(AnnounceDTO announceDTO) {
		con = getConnection();
		sql = " update announcement "
				+ " set announce_content=? "
				+ " where announce_subject=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, announceDTO.getAnnounceContent());
			pstmt.setString(2, announceDTO.getAnnounceSubject());
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 수정되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public AnnounceDTO selectOne(String announceSubject) {
		AnnounceDTO announceDTO = null;
		con = getConnection();
		sql = " select announce_subject, announce_content, announce_date "
				+ " from announcement "
				+ " where announce_subject = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, announceSubject);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				announceDTO = new AnnounceDTO();
				announceDTO.setAnnounceContent(rs.getString("announce_content"));
				announceDTO.setAnnounceDate(rs.getDate("announce_date"));
				announceDTO.setAnnounceSubject(rs.getString("announce_subject"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return announceDTO;
	}
	public List<AnnounceDTO> selectAll() {
		List<AnnounceDTO> list = new ArrayList<AnnounceDTO>();
		con = getConnection();
		sql = " select announce_subject, announce_content, announce_date "
				+ " from announcement "
				+ " order by announce_date desc ";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				AnnounceDTO announceDTO = new AnnounceDTO();
				announceDTO.setAnnounceContent(rs.getString("announce_content"));
				announceDTO.setAnnounceDate(rs.getDate("announce_date"));
				announceDTO.setAnnounceSubject(rs.getString("announce_subject"));
				list.add(announceDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}
	public void annInsert(AnnounceDTO announceDTO) {
		con = getConnection();
		sql = " insert into announcement(announce_subject, announce_content, announce_date) "
				+ " values(?,?,sysdate) ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, announceDTO.getAnnounceSubject());
			pstmt.setString(2, announceDTO.getAnnounceContent());
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 삽입되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
