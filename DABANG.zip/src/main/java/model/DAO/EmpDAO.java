package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.DTO.AuthInfo1DTO;
import model.DTO.EmpDTO;

public class EmpDAO {
	String jdbcURL;
	String jdbcDriver;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String sql;
	public EmpDAO() {
		jdbcDriver = "oracle.jdbc.driver.OracleDriver";
		jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	}
	public Connection getConnection() {
		Connection conn= null;
		try {
			Class.forName(jdbcDriver);
			conn = DriverManager.getConnection(jdbcURL,"hkk123","oracle");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	public String empPwCk (String empNo, String employeePw) {
		String ck = null;
		con = getConnection();
		sql = " select 1 from employees "
				+ " where emp_no = ? "
				+ " and emp_pw = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, empNo);
			pstmt.setString(2, employeePw);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				ck = rs.getString("1");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ck;
	}
	public void empUpdate(EmpDTO dto) {
		con = getConnection();
		sql = " update employees "
				+ " set EMP_PW = ?, "
				+ " EMP_PHONE=?, "
				+ " EMP_SAL=?, "
				+ " HIRE_DATE=?, "
				+ " DEPARTMENT_NAME=?, "
				+ " JOB_TITLE=?, "
				+ " EMP_ADDR=?, "
				+ " EMP_ADDR_DETAIL=?, "
				+ " EMP_POSTCODE=? "
				+ " where EMP_NO = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getEmpPw());
			pstmt.setString(2, dto.getEmpPhone());
			pstmt.setLong(3, dto.getEmpSal());
			pstmt.setDate(4, new java.sql.Date(dto.getEmpHireDate().getTime()));
			pstmt.setString(5, dto.getEmpDepartmentName());
			pstmt.setString(6, dto.getEmpJobTitle());
			pstmt.setString(7, dto.getEmpAddr());
			pstmt.setString(8, dto.getEmpAddrDetail());
			pstmt.setString(9, dto.getEmpPostCode());
			pstmt.setString(10, dto.getEmpNo());
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 수정되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public String empAutoNum() {
		String empNo=null;
		con = getConnection();
		sql = "select emp_seq.nextval from dual";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			empNo = "emp"+rs.getString("nextval");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empNo;
	}
	public void employeeDelete(String empNo) {
		con = getConnection();
		sql = " delete from employees where EMP_NO = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, empNo);
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 삭제되었습니다");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void employeeUpdate(EmpDTO dto) {
		con = getConnection();
		sql = " update employees "
				+ " set EMP_PW =?, "
				+ " EMP_GENDER=?, "
				+ " EMP_PHONE=?, "
				+ " EMP_SAL=?, "
				+ " HIRE_DATE=?, "
				+ " DEPARTMENT_NAME=?, "
				+ " JOB_TITLE=?, "
				+ " EMP_ADDR=?, "
				+ " EMP_ADDR_DETAIL=?, "
				+ " EMP_POSTCODE=? "
				+ " where EMP_NO = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getEmpPw());
			pstmt.setString(2, dto.getEmpGender());
			pstmt.setString(3, dto.getEmpPhone());
			pstmt.setLong(4, dto.getEmpSal());
			pstmt.setDate(5, new java.sql.Date(dto.getEmpHireDate().getTime()));
			pstmt.setString(6, dto.getEmpDepartmentName());
			pstmt.setString(7, dto.getEmpJobTitle());
			pstmt.setString(8, dto.getEmpAddr());
			pstmt.setString(9, dto.getEmpAddrDetail());
			pstmt.setString(10, dto.getEmpPostCode());
			pstmt.setString(11, dto.getEmpNo());
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 수정되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public EmpDTO selectOne(String empNo) {
		EmpDTO dto = null;
		con = getConnection();
		sql = " select EMP_NO, EMP_PW, EMP_FIRST_NAME, EMP_LAST_NAME, EMP_GENDER, "
				+ " EMP_PHONE, EMP_BIRTH, EMP_SAL, HIRE_DATE, DEPARTMENT_NAME, JOB_TITLE, EMP_ADDR, EMP_ADDR_DETAIL, EMP_POSTCODE  "
				+ " from employees "
				+ " where EMP_NO = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, empNo);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				dto = new EmpDTO();
				dto.setEmpAddr(rs.getString("EMP_ADDR"));
				dto.setEmpBirth(rs.getDate("EMP_BIRTH"));
				dto.setEmpDepartmentName(rs.getString("DEPARTMENT_NAME"));
				dto.setEmpFirstName(rs.getString("EMP_FIRST_NAME"));
				dto.setEmpGender(rs.getString("EMP_GENDER"));
				dto.setEmpHireDate(rs.getDate("HIRE_DATE"));
				dto.setEmpJobTitle(rs.getString("JOB_TITLE"));
				dto.setEmpLastName(rs.getString("EMP_LAST_NAME"));
				dto.setEmpNo(rs.getString("EMP_NO"));
				dto.setEmpPhone(rs.getString("EMP_PHONE"));
				dto.setEmpPw(rs.getString("EMP_PW"));
				dto.setEmpSal(rs.getLong("EMP_SAL"));
				dto.setEmpAddrDetail(rs.getString("EMP_ADDR_DETAIL"));
				dto.setEmpPostCode(rs.getString("EMP_POSTCODE"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return dto;
	}
	public List<EmpDTO> selectAll(){
		List<EmpDTO> list = new ArrayList<EmpDTO>();
		con = getConnection();
		sql = " select EMP_NO, EMP_PW, EMP_FIRST_NAME, EMP_LAST_NAME, EMP_GENDER, "
				+ " EMP_PHONE, EMP_BIRTH, EMP_SAL, HIRE_DATE, DEPARTMENT_NAME, JOB_TITLE, EMP_ADDR, EMP_ADDR_DETAIL, EMP_POSTCODE "
				+ " from employees ";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				EmpDTO dto = new EmpDTO();
				dto.setEmpAddr(rs.getString("EMP_ADDR"));
				dto.setEmpBirth(rs.getDate("EMP_BIRTH"));
				dto.setEmpDepartmentName(rs.getString("DEPARTMENT_NAME"));
				dto.setEmpFirstName(rs.getString("EMP_FIRST_NAME"));
				dto.setEmpGender(rs.getString("EMP_GENDER"));
				dto.setEmpHireDate(rs.getDate("HIRE_DATE"));
				dto.setEmpJobTitle(rs.getString("JOB_TITLE"));
				dto.setEmpLastName(rs.getString("EMP_LAST_NAME"));
				dto.setEmpNo(rs.getString("EMP_NO"));
				dto.setEmpPhone(rs.getString("EMP_PHONE"));
				dto.setEmpPw(rs.getString("EMP_PW"));
				dto.setEmpSal(rs.getLong("EMP_SAL"));
				dto.setEmpAddrDetail(rs.getString("EMP_ADDR_DETAIL"));
				dto.setEmpPostCode(rs.getString("EMP_POSTCODE"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}
	public void employeeInsert(EmpDTO dto) {
		con = getConnection();
		sql = " insert into employees(EMP_NO, EMP_PW, EMP_FIRST_NAME, EMP_LAST_NAME, EMP_GENDER, "
				+ " EMP_PHONE, EMP_BIRTH, EMP_SAL, HIRE_DATE, DEPARTMENT_NAME, JOB_TITLE, EMP_ADDR, EMP_ADDR_DETAIL, EMP_POSTCODE ) "
				+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getEmpNo());
			pstmt.setString(2, dto.getEmpPw());
			pstmt.setString(3, dto.getEmpFirstName());
			pstmt.setString(4, dto.getEmpLastName());
			pstmt.setString(5, dto.getEmpGender());
			pstmt.setString(6, dto.getEmpPhone());
			pstmt.setDate(7, new java.sql.Date(dto.getEmpBirth().getTime()));
			pstmt.setLong(8, dto.getEmpSal());
			pstmt.setDate(9, new java.sql.Date(dto.getEmpHireDate().getTime()));
			pstmt.setString(10, dto.getEmpDepartmentName());
			pstmt.setString(11, dto.getEmpJobTitle());
			pstmt.setString(12, dto.getEmpAddr());
			pstmt.setString(13, dto.getEmpAddrDetail());
			pstmt.setString(14, dto.getEmpPostCode());
			int i = pstmt.executeUpdate();
			System.out.println(i+"개가 삽입되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
