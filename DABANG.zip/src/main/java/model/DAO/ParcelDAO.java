package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.DTO.ParcelDTO;

public class ParcelDAO {
   String jdbcURL;
   String jdbcDriver;
   Connection con;
   PreparedStatement pstmt;
   ResultSet rs;
   String sql;
   public ParcelDAO() {
      jdbcDriver = "oracle.jdbc.driver.OracleDriver";
      jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
   }
   public Connection getConnection() {
      Connection conn = null;
      try {
         Class.forName(jdbcDriver);
         conn = DriverManager.getConnection(jdbcURL, "hkk123", "oracle");
      } catch (ClassNotFoundException e) {
         e.printStackTrace();
      } catch (SQLException e) {
         e.printStackTrace();
      }
      return conn;
   }
   
   public void parDel(String parcelNo) {
      con = getConnection();
      sql = "delete from parcel where PARCEL_NO = ?";
      try {
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1, parcelNo);
         pstmt.executeUpdate();
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }
   public void parUpdate(ParcelDTO parDTO) {
      con = getConnection();
      sql = "update parcel set BRAND = ?, BRAND_NO = ?, CONSTRUCT_FIRM_NAME = ?, DEVELOPER_NAME = ?, PARCEL_ADDR = ?,"
            + "       PARCEL_PRICE = ?, BUILDING_TYPE = ?, SUPPLY_TYPE = ?, MONOPOLY_RIGHT = ?, RESTRICT_REGION = ?, PRICE_CEILING = ?,"
            + "       RESTRICT_PERIOD = ?, AREA = ?, RECRUIT_DATE = ?, MOVE_DATE = ?, PARCEL_TEL = ?, TOTAL_HOUSE_NO = ?, PARCEL_HOUSE_NO = ?,"
            + "       LOW_HIGH_FLOOR = ?, HOUSING_AREA = ?, emp_updateNo = ? "
            + " where PARCEL_NO = ? ";
      try {
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1, parDTO.getBrand());
         pstmt.setString(2, parDTO.getBrandNo());
         pstmt.setString(3, parDTO.getConstructFirmName());
         pstmt.setString(4, parDTO.getDeveloperName());
         pstmt.setString(5, parDTO.getParcelAddr());
         pstmt.setString(6, parDTO.getParcelPrice());
         pstmt.setString(7, parDTO.getBuildingType());
         pstmt.setString(8, parDTO.getSupplyType());
         pstmt.setString(9, parDTO.getMonopolyRight());
         pstmt.setString(10, parDTO.getRestrictRegion());
         pstmt.setString(11, parDTO.getPriceCeiling());
         pstmt.setString(12, parDTO.getRestrictPeriod());
         pstmt.setString(13, parDTO.getArea());
         pstmt.setDate(14, new java.sql.Date(parDTO.getRecruitDate().getTime()));
         pstmt.setDate(15, new java.sql.Date(parDTO.getMoveDate().getTime()));
         pstmt.setString(16, parDTO.getParcelTel());
         pstmt.setInt(17, parDTO.getTotalHouseNo());
         pstmt.setInt(18, parDTO.getParcelHouseNo());
         pstmt.setString(19, parDTO.getLowHighFloor());
         pstmt.setString(20, parDTO.getHousingArea());
         pstmt.setString(21, parDTO.getEmpUpdateNo());
         pstmt.setString(22, parDTO.getParcelNo());
         int i = pstmt.executeUpdate();
         System.out.println(i + "개가 수정되었습니다.");
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }
   public ParcelDTO parDetail(String parcelNo) {
      ParcelDTO parDTO = null;
      con = getConnection();
      sql = "select PARCEL_NO, BRAND, BRAND_NO, CONSTRUCT_FIRM_NAME, DEVELOPER_NAME, PARCEL_ADDR,"
            + "       PARCEL_PRICE, BUILDING_TYPE, SUPPLY_TYPE, MONOPOLY_RIGHT, RESTRICT_REGION, PRICE_CEILING,"
            + "       RESTRICT_PERIOD, AREA, RECRUIT_DATE, MOVE_DATE, PARCEL_TEL, TOTAL_HOUSE_NO, PARCEL_HOUSE_NO,"
            + "       LOW_HIGH_FLOOR, HOUSING_AREA, emp_no, emp_updateNo "
            + " from parcel"
            + " where PARCEL_NO = ?";
      try {
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1, parcelNo);
         rs = pstmt.executeQuery();
         if(rs.next()) {
            parDTO = new ParcelDTO();
            parDTO.setArea(rs.getString("AREA"));
            parDTO.setBrand(rs.getString("BRAND"));
            parDTO.setBrandNo(rs.getString("BRAND_NO"));
            parDTO.setBuildingType(rs.getString("BUILDING_TYPE"));
            parDTO.setConstructFirmName(rs.getString("CONSTRUCT_FIRM_NAME"));
            parDTO.setDeveloperName(rs.getString("DEVELOPER_NAME"));
            parDTO.setHousingArea(rs.getString("HOUSING_AREA"));
            parDTO.setLowHighFloor(rs.getString("LOW_HIGH_FLOOR"));
            parDTO.setMonopolyRight(rs.getString("MONOPOLY_RIGHT"));
            parDTO.setMoveDate(rs.getDate("MOVE_DATE"));
            parDTO.setParcelAddr(rs.getString("PARCEL_ADDR"));
            parDTO.setParcelHouseNo(rs.getInt("PARCEL_HOUSE_NO"));
            parDTO.setParcelNo(rs.getString("PARCEL_NO"));
            parDTO.setParcelPrice(rs.getString("PARCEL_PRICE"));
            parDTO.setParcelTel(rs.getString("PARCEL_TEL"));
            parDTO.setPriceCeiling(rs.getString("PRICE_CEILING"));
            parDTO.setRecruitDate(rs.getDate("RECRUIT_DATE"));
            parDTO.setRestrictPeriod(rs.getString("RESTRICT_PERIOD"));
            parDTO.setRestrictRegion(rs.getString("RESTRICT_REGION"));
            parDTO.setSupplyType(rs.getString("SUPPLY_TYPE"));
            parDTO.setTotalHouseNo(rs.getInt("TOTAL_HOUSE_NO"));
            parDTO.setEmpNo(rs.getString("emp_no"));
            parDTO.setEmpUpdateNo(rs.getString("emp_updateNo"));
         }
      } catch (SQLException e) {
         e.printStackTrace();
      }
      return parDTO;
   }
   public List<ParcelDTO> selectAll(){
      List<ParcelDTO> list = new ArrayList<ParcelDTO>();
      con = getConnection();
      sql = "select PARCEL_NO, BRAND, BRAND_NO, CONSTRUCT_FIRM_NAME, DEVELOPER_NAME, PARCEL_ADDR,"
            + "       PARCEL_PRICE, BUILDING_TYPE, SUPPLY_TYPE, MONOPOLY_RIGHT, RESTRICT_REGION, PRICE_CEILING,"
            + "       RESTRICT_PERIOD, AREA, RECRUIT_DATE, MOVE_DATE, PARCEL_TEL, TOTAL_HOUSE_NO, PARCEL_HOUSE_NO,"
            + "       LOW_HIGH_FLOOR, HOUSING_AREA, emp_no, emp_updateNo"
            + " from parcel";
      try {
         pstmt = con.prepareStatement(sql);
         rs = pstmt.executeQuery();
         while(rs.next()) {
            ParcelDTO parDTO = new ParcelDTO();
            parDTO.setArea(rs.getString("AREA"));
            parDTO.setBrand(rs.getString("BRAND"));
            parDTO.setBrandNo(rs.getString("BRAND_NO"));
            parDTO.setBuildingType(rs.getString("BUILDING_TYPE"));
            parDTO.setConstructFirmName(rs.getString("CONSTRUCT_FIRM_NAME"));
            parDTO.setDeveloperName(rs.getString("DEVELOPER_NAME"));
            parDTO.setHousingArea(rs.getString("HOUSING_AREA"));
            parDTO.setLowHighFloor(rs.getString("LOW_HIGH_FLOOR"));
            parDTO.setMonopolyRight(rs.getString("MONOPOLY_RIGHT"));
            parDTO.setMoveDate(rs.getDate("MOVE_DATE"));
            parDTO.setParcelAddr(rs.getString("PARCEL_ADDR"));
            parDTO.setParcelHouseNo(rs.getInt("PARCEL_HOUSE_NO"));
            parDTO.setParcelNo(rs.getString("PARCEL_NO"));
            parDTO.setParcelPrice(rs.getString("PARCEL_PRICE"));
            parDTO.setParcelTel(rs.getString("PARCEL_TEL"));
            parDTO.setPriceCeiling(rs.getString("PRICE_CEILING"));
            parDTO.setRecruitDate(rs.getDate("RECRUIT_DATE"));
            parDTO.setRestrictPeriod(rs.getString("RESTRICT_PERIOD"));
            parDTO.setRestrictRegion(rs.getString("RESTRICT_REGION"));
            parDTO.setSupplyType(rs.getString("SUPPLY_TYPE"));
            parDTO.setTotalHouseNo(rs.getInt("TOTAL_HOUSE_NO"));
            parDTO.setEmpNo(rs.getString("emp_no"));
            parDTO.setEmpUpdateNo(rs.getString("emp_updateNo"));
            list.add(parDTO);
         }
      } catch (SQLException e) {
         e.printStackTrace();
      }
      return list;
   }
   public void parInsert(ParcelDTO parDTO) {
      con = getConnection();
      sql = "insert into parcel(PARCEL_NO, BRAND, BRAND_NO, CONSTRUCT_FIRM_NAME, DEVELOPER_NAME, PARCEL_ADDR,"
            + "                    PARCEL_PRICE, BUILDING_TYPE, SUPPLY_TYPE, MONOPOLY_RIGHT, RESTRICT_REGION, PRICE_CEILING,"
            + "                    RESTRICT_PERIOD, AREA, RECRUIT_DATE, MOVE_DATE, PARCEL_TEL, TOTAL_HOUSE_NO, PARCEL_HOUSE_NO,"
            + "                    LOW_HIGH_FLOOR, HOUSING_AREA, EMP_NO)"
            + " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      try {
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1, parDTO.getParcelNo());
         pstmt.setString(2, parDTO.getBrand());
         pstmt.setString(3, parDTO.getBrandNo());
         pstmt.setString(4, parDTO.getConstructFirmName());
         pstmt.setString(5, parDTO.getDeveloperName());
         pstmt.setString(6, parDTO.getParcelAddr());
         pstmt.setString(7, parDTO.getParcelPrice());
         pstmt.setString(8, parDTO.getBuildingType());
         pstmt.setString(9, parDTO.getSupplyType());
         pstmt.setString(10, parDTO.getMonopolyRight());
         pstmt.setString(11, parDTO.getRestrictRegion());
         pstmt.setString(12, parDTO.getPriceCeiling());
         pstmt.setString(13, parDTO.getRestrictPeriod());
         pstmt.setString(14, parDTO.getArea());
         pstmt.setDate(15, new java.sql.Date(parDTO.getRecruitDate().getTime()));
         pstmt.setDate(16, new java.sql.Date(parDTO.getMoveDate().getTime()));
         pstmt.setString(17, parDTO.getParcelTel());
         pstmt.setInt(18, parDTO.getTotalHouseNo());
         pstmt.setInt(19, parDTO.getParcelHouseNo());
         pstmt.setString(20, parDTO.getLowHighFloor());
         pstmt.setString(21, parDTO.getHousingArea());
         pstmt.setString(22, parDTO.getEmpNo());
         pstmt.executeUpdate();
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }
}