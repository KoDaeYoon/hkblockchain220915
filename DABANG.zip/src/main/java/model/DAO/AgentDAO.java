package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.DTO.AgentDTO;

public class AgentDAO {
	String jdbcURL;
	String jdbcDriver;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String sql;

	public AgentDAO() {
		jdbcDriver = "oracle.jdbc.driver.OracleDriver";
		jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	}

	public Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName(jdbcDriver);
			conn = DriverManager.getConnection(jdbcURL, "hkk123", "oracle");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	public AgentDTO idchkselectOne(String agentId) {
		AgentDTO dto = null;
		con = getConnection();
		sql = " select AGENT_ID from agent where AGENT_ID= ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, agentId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				dto = new AgentDTO();
				dto.setAgentId(rs.getString("AGENT_ID"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dto;
	}

	public String agentAutoNum() {
		String agentNo = null;
		con = getConnection();
		sql = "select agent_seq.nextval from dual ";

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			agentNo = "agent" + rs.getString("nextval");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return agentNo;
	}

	public void agentDelete(String agentId) {
		con = getConnection();
		sql = "delete from agent where agent_id = ?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, agentId);
			int i = pstmt.executeUpdate();
			System.out.println(i + "개가 삭제되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public AgentDTO agentselectOne(String agentId) {
		AgentDTO dto = null;
		con = getConnection();
		sql = " select AGENT_NO, CORPORATE_NO, AGENT_NAME, AGENT_ADDR, AGENT_TEL, "
				+ " AGENT_EMAIL, AGENT_ID, AGENT_PW, EXPONENT_NAME, EXPONENT_TEL" + "	from agent"
				+ " where agent_id = ?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, agentId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				dto = new AgentDTO();
				dto.setAgentAddr(rs.getString("AGENT_ADDR"));
				dto.setAgentEmail(rs.getString("AGENT_EMAIL"));
				dto.setAgentId(rs.getString("AGENT_ID"));
				dto.setAgentName(rs.getString("AGENT_NAME"));
				dto.setAgentPw(rs.getString("AGENT_PW"));
				dto.setAgentTel(rs.getString("AGENT_TEL"));
				dto.setCorporateNo(rs.getString("CORPORATE_NO"));
				dto.setAgentNo(rs.getString("AGENT_NO"));
				dto.setExponentName(rs.getString("EXPONENT_NAME"));
				dto.setExponentTel(rs.getString("EXPONENT_TEL"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dto;
	}

	public void agentUpdate(AgentDTO dto) {
		con = getConnection();
		sql = " update agent"
				+ " set AGENT_NAME = ?, AGENT_ADDR = ?, AGENT_TEL= ?, EXPONENT_NAME = ?, EXPONENT_TEL = ?,"
				+ " AGENT_EMAIL =?, AGENT_NO=?, CORPORATE_NO=?, AGENT_ID=?, AGENT_PW=?" + " where AGENT_ID= ? ";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getAgentName());
			pstmt.setString(2, dto.getAgentAddr());
			pstmt.setString(3, dto.getAgentTel());
			pstmt.setString(4, dto.getExponentName());
			pstmt.setString(5, dto.getExponentTel());
			pstmt.setString(6, dto.getAgentEmail());
			pstmt.setString(7, dto.getAgentNo());
			pstmt.setString(8, dto.getCorporateNo());
			pstmt.setString(9, dto.getAgentId());
			pstmt.setString(10, dto.getAgentPw());
			pstmt.setString(11, dto.getAgentId());
			int i = pstmt.executeUpdate();
			System.out.println(i + "개가 수정되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
	}

	public AgentDTO agentselectOne(String agentId, String agentPW) {
		AgentDTO dto = null;
		con = getConnection();
		sql = " select AGENT_NO,CORPORATE_NO,AGENT_NAME,AGENT_ADDR,AGENT_TEL,EXPONENT_NAME,EXPONENT_TEL,"
				+ " AGENT_EMAIL,AGENT_ID,AGENT_PW" + " where AGENT_ID= ? and AGENT_PW";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, agentId);
			pstmt.setString(2, agentPW);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				dto = new AgentDTO();
				dto.setAgentAddr(rs.getString("AGENT_ADDR"));
				dto.setAgentEmail(rs.getString("AGENT_EMAIL"));
				dto.setAgentId(rs.getString("AGENT_ID"));
				dto.setAgentName(rs.getString("AGENT_NAME"));
				dto.setAgentNo(rs.getString("AGENT_NO"));
				dto.setAgentPw(rs.getString("AGENT_PW"));
				dto.setAgentTel(rs.getString("AGENT_TEL"));
				dto.setCorporateNo(rs.getString("CORPORATE_NO"));
				dto.setExponentName(rs.getString("EXPONENT_NAME"));
				dto.setExponentTel(rs.getString("EXPONENT_TEL"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return dto;
	}

	public void agentInsert(AgentDTO agent) {
		con = getConnection();
		sql = " insert into agent(AGENT_NO, CORPORATE_NO, AGENT_NAME, EXPONENT_NAME, EXPONENT_TEL,"
				+ " AGENT_ADDR, AGENT_TEL, AGENT_EMAIL, AGENT_ID, AGENT_PW)"
				+ " values((select nvl(max(AGENT_NO),0)+1 from agent),?,?,?,?,?,?,?,?,?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, agent.getCorporateNo());
			pstmt.setString(2, agent.getAgentName());
			pstmt.setString(3, agent.getExponentName());
			pstmt.setString(4, agent.getExponentTel());
			pstmt.setString(5, agent.getAgentAddr());
			pstmt.setString(6, agent.getAgentTel());
			pstmt.setString(7, agent.getAgentEmail());
			pstmt.setString(8, agent.getAgentId());
			pstmt.setString(9, agent.getAgentPw());
			int i = pstmt.executeUpdate();
			System.out.println(i + "개가 삽입되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
	}

	public void close() {
		if (rs != null)
			try {
				rs.close();
			} catch (Exception e) {
			}
		if (con != null)
			try {
				con.close();
			} catch (Exception e) {
			}
		if (pstmt != null)
			try {
				pstmt.close();
			} catch (Exception e) {
			}
	}

	public List<AgentDTO> selectAll() {
		List<AgentDTO> list = new ArrayList<AgentDTO>();
		con = getConnection();
		sql = " select AGENT_NO, CORPORATE_NO, AGENT_NAME, AGENT_ADDR," + " AGENT_TEL, EXPONENT_NAME, EXPONENT_TEL,"
				+ " AGENT_EMAIL, AGENT_ID, AGENT_PW" + " from agent" + " order by AGENT_NO";

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				AgentDTO dto = new AgentDTO();
				dto.setAgentNo(rs.getString("AGENT_NO"));
				dto.setCorporateNo(rs.getString("CORPORATE_NO"));
				dto.setAgentName(rs.getString("AGENT_NAME"));
				dto.setAgentAddr(rs.getString("AGENT_ADDR"));
				dto.setAgentTel(rs.getString("AGENT_TEL"));
				dto.setExponentName(rs.getString("EXPONENT_NAME"));
				dto.setExponentTel(rs.getString("EXPONENT_TEL"));
				dto.setAgentEmail(rs.getString("AGENT_EMAIL"));
				dto.setAgentId(rs.getString("AGENT_ID"));
				dto.setAgentPw(rs.getString("AGENT_PW"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}
