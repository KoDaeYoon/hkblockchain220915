package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.DTO.AuthInfo1DTO;

public class LoginDAO {
	String jdbcURL;
	String jdbcDriver;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String sql;
	public LoginDAO() {
	jdbcDriver = "oracle.jdbc.driver.OracleDriver";
	jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	}
	public Connection getConnection() {
	Connection conn = null;
	try {
	Class.forName(jdbcDriver);
	conn = DriverManager.getConnection( jdbcURL,"hkk123","oracle");
	}catch(Exception e) {e.printStackTrace();}
	return conn;
	}
    public AuthInfo1DTO selectOne(String userId) {
    	AuthInfo1DTO dto = null;
    	con = getConnection();
      	sql = " select mem_id user_id, mem_pw user_pw, concat(last_name,first_name) user_name, 'mem' grade"
    			+ " from member"
    			+ " where mem_id =?"
    			+ " union"
    			+ " select EMP_NO, EMP_PW, concat(EMP_LAST_NAME, EMP_FIRST_NAME), 'emp' grade"
    			+ " from employees"
    			+ " where emp_no = ?" 
    			+ " union"                // agent 로그인 추가
    			+ " select agent_id, agent_pw, agent_name, 'agent' grade"
    			+ " from agent"
    			+ " where agent_id=?"; 
    try {
		pstmt= con.prepareStatement(sql);
		pstmt.setString(1, userId);
		pstmt.setString(2, userId);
		pstmt.setString(3, userId);
		rs = pstmt.executeQuery();
		if(rs.next()) {
			dto = new AuthInfo1DTO();
			dto.setUserId(rs.getString("user_id"));
			dto.setUserPw(rs.getString("user_pw"));
			dto.setUserName(rs.getString("user_name"));
			dto.setGrade(rs.getString("grade"));
	}
	} catch (SQLException e) {
			e.printStackTrace();
	}finally {
		close();
	}
	return dto;
    }
	public void close() {
		if(rs !=null)try {rs.close();}catch (Exception e) {}
		if(con !=null)try {con.close();}catch (Exception e) {}
		if(pstmt !=null)try {pstmt.close();}catch (Exception e) {}
	}
}
