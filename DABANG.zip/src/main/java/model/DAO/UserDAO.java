package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.DTO.MemberDTO;
import model.DTO.UserDTO;

public class UserDAO {
	String jdbcURL;
	String jdbcDriver;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String sql;
	public UserDAO() {
	jdbcDriver = "oracle.jdbc.driver.OracleDriver";
	jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	}
	public Connection getConnection() {
	Connection conn = null;
	try {
	Class.forName(jdbcDriver);
	conn = DriverManager.getConnection( jdbcURL,"hkk123","oracle");
	}catch(Exception e) {e.printStackTrace();}
	return conn;
	}
	public UserDTO userIdChkSelectOne(String memId) {
		UserDTO dto = null;
		con = getConnection();
		sql= " select MEM_ID from member where MEM_ID = ?";
		
		try {
			pstmt =con.prepareStatement(sql);
			pstmt.setString(1, memId);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto = new UserDTO();
				dto.setMemId(rs.getString("MEM_ID"));
				System.out.println(rs.getString("MEM_ID"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dto;
	}
	public MemberDTO userOne(String memId) {
	      MemberDTO userDTO = null;
	      con = getConnection();
	      sql = " select MEM_NO,FIRST_NAME,LAST_NAME,MEM_ID,MEM_PW,MEM_BIRTH,MEM_GENDER,MEM_TEL,MEM_EMAIL "
	            + " from member "
	            + " where mem_id = ? ";
	      try {
	         pstmt = con.prepareStatement(sql);
	         pstmt.setString(1, memId);
	         rs = pstmt.executeQuery();
	         if(rs.next()) {
	            userDTO = new MemberDTO();
	            userDTO.setFirstName(rs.getString("FIRST_NAME"));
	            userDTO.setLastName(rs.getString("LAST_NAME"));
	            userDTO.setMemBirth(rs.getDate("MEM_BIRTH"));
	            userDTO.setMemEmail(rs.getString("MEM_EMAIL"));
	            userDTO.setMemGender(rs.getString("MEM_GENDER"));
	            userDTO.setMemId(rs.getString("MEM_ID"));
	            userDTO.setMemNo(rs.getString("MEM_NO"));
	            userDTO.setMemPw(rs.getString("MEM_PW"));
	            userDTO.setMemTel(rs.getString("MEM_TEL"));
	         }
	      } catch (SQLException e) {
	         // TODO Auto-generated catch block
	         e.printStackTrace();
	      }
	      return userDTO;
	   }
	public void userInsert(UserDTO dto) {
		con = getConnection();
		sql = " insert into member(MEM_NO, FIRST_NAME, LAST_NAME, MEM_ID, MEM_PW, MEM_BIRTH,"
				+ "                MEM_GENDER, MEM_TEL, MEM_EMAIL)"
				+ " values((select nvl(max(MEM_NO),0)+1 from member),?,?,?,?,?,?,?,?)";
		try {
			pstmt =con.prepareStatement(sql);
			pstmt.setString(1, dto.getFirstName());
			pstmt.setString(2, dto.getLastName());
			pstmt.setString(3, dto.getMemId());
			pstmt.setString(4, dto.getMemPw());
			pstmt.setDate(5, new java.sql.Date(dto.getMembirth().getTime()));
			pstmt.setString(6, dto.getMemGender());
			pstmt.setString(7, dto.getMemTel());
			pstmt.setString(8, dto.getMemEmail());
			int i = pstmt.executeUpdate();
			System.out.println(i +"개가 삽입되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}
		}
		public void close() {
			if(rs !=null)try {rs.close();}catch (Exception e) {}
			if(con !=null)try {con.close();}catch (Exception e) {}
			if(pstmt !=null)try {pstmt.close();}catch (Exception e) {}
		}
}



