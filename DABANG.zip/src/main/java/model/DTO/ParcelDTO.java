package model.DTO;

import java.util.Date;

public class ParcelDTO {
	String parcelNo;
	String brand;
	String brandNo;
	String constructFirmName;
	String developerName;
	String parcelAddr;
	String parcelPrice;
	String buildingType;
	String supplyType;
	String monopolyRight;
	String restrictRegion;
	String priceCeiling;
	String restrictPeriod;
	String area;
	Date recruitDate;
	Date moveDate;
	String parcelTel;
	int totalHouseNo;
	int parcelHouseNo;
	String lowHighFloor;
	String housingArea;
	String empNo;
	String empUpdateNo;
	
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getEmpUpdateNo() {
		return empUpdateNo;
	}
	public void setEmpUpdateNo(String empUpdateNo) {
		this.empUpdateNo = empUpdateNo;
	}
	public String getParcelNo() {
		return parcelNo;
	}
	public void setParcelNo(String parcelNo) {
		this.parcelNo = parcelNo;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getBrandNo() {
		return brandNo;
	}
	public void setBrandNo(String brandNo) {
		this.brandNo = brandNo;
	}
	public String getConstructFirmName() {
		return constructFirmName;
	}
	public void setConstructFirmName(String constructFirmName) {
		this.constructFirmName = constructFirmName;
	}
	public String getDeveloperName() {
		return developerName;
	}
	public void setDeveloperName(String developerName) {
		this.developerName = developerName;
	}
	public String getParcelAddr() {
		return parcelAddr;
	}
	public void setParcelAddr(String parcelAddr) {
		this.parcelAddr = parcelAddr;
	}
	public String getParcelPrice() {
		return parcelPrice;
	}
	public void setParcelPrice(String parcelPrice) {
		this.parcelPrice = parcelPrice;
	}
	public String getBuildingType() {
		return buildingType;
	}
	public void setBuildingType(String buildingType) {
		this.buildingType = buildingType;
	}
	public String getSupplyType() {
		return supplyType;
	}
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	public String getMonopolyRight() {
		return monopolyRight;
	}
	public void setMonopolyRight(String monopolyRight) {
		this.monopolyRight = monopolyRight;
	}
	public String getRestrictRegion() {
		return restrictRegion;
	}
	public void setRestrictRegion(String restrictRegion) {
		this.restrictRegion = restrictRegion;
	}
	public String getPriceCeiling() {
		return priceCeiling;
	}
	public void setPriceCeiling(String priceCeiling) {
		this.priceCeiling = priceCeiling;
	}
	public String getRestrictPeriod() {
		return restrictPeriod;
	}
	public void setRestrictPeriod(String restrictPeriod) {
		this.restrictPeriod = restrictPeriod;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public Date getRecruitDate() {
		return recruitDate;
	}
	public void setRecruitDate(Date recruitDate) {
		this.recruitDate = recruitDate;
	}
	public Date getMoveDate() {
		return moveDate;
	}
	public void setMoveDate(Date moveDate) {
		this.moveDate = moveDate;
	}
	public String getParcelTel() {
		return parcelTel;
	}
	public void setParcelTel(String parcelTel) {
		this.parcelTel = parcelTel;
	}
	public int getTotalHouseNo() {
		return totalHouseNo;
	}
	public void setTotalHouseNo(int totalHouseNo) {
		this.totalHouseNo = totalHouseNo;
	}
	public int getParcelHouseNo() {
		return parcelHouseNo;
	}
	public void setParcelHouseNo(int parcelHouseNo) {
		this.parcelHouseNo = parcelHouseNo;
	}
	public String getLowHighFloor() {
		return lowHighFloor;
	}
	public void setLowHighFloor(String lowHighFloor) {
		this.lowHighFloor = lowHighFloor;
	}
	public String getHousingArea() {
		return housingArea;
	}
	public void setHousingArea(String housingArea) {
		this.housingArea = housingArea;
	}

}
