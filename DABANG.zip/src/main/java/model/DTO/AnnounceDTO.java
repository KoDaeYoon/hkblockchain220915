package model.DTO;

import java.util.Date;

public class AnnounceDTO {
	Date announceDate;
	String announceSubject;
	String announceContent;
	String empNo;
	
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public Date getAnnounceDate() {
		return announceDate;
	}
	public void setAnnounceDate(Date announceDate) {
		this.announceDate = announceDate;
	}
	public String getAnnounceSubject() {
		return announceSubject;
	}
	public void setAnnounceSubject(String announceSubject) {
		this.announceSubject = announceSubject;
	}
	public String getAnnounceContent() {
		return announceContent;
	}
	public void setAnnounceContent(String announceContent) {
		this.announceContent = announceContent;
	}
	
}
