package model.DTO;

import java.util.Date;

public class EstateDTO {
	String realNo;
	String realName;
	String realAddr;
	String realPrice;
	String mediationPay;
	String option1;
	String securityFacil;
	String surroundFacil;
	String realInform;
	String administrationCost;
	String productType;
	String productPhoto;
	String untactContract;
	Date useApproveDate;
	Date registrationDate;
	String memNo;
	public String getMemNo() {
		return memNo;
	}
	public void setMemNo(String memNo) {
		this.memNo = memNo;
	}
	public String getRealNo() {
		return realNo;
	}
	public void setRealNo(String realNo) {
		this.realNo = realNo;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getRealAddr() {
		return realAddr;
	}
	public void setRealAddr(String realAddr) {
		this.realAddr = realAddr;
	}
	public String getRealPrice() {
		return realPrice;
	}
	public void setRealPrice(String realPrice) {
		this.realPrice = realPrice;
	}
	public String getMediationPay() {
		return mediationPay;
	}
	public void setMediationPay(String mediationPay) {
		this.mediationPay = mediationPay;
	}
	public String getOption1() {
		return option1;
	}
	public void setOption1(String option1) {
		this.option1 = option1;
	}
	public String getSecurityFacil() {
		return securityFacil;
	}
	public void setSecurityFacil(String securityFacil) {
		this.securityFacil = securityFacil;
	}
	public String getSurroundFacil() {
		return surroundFacil;
	}
	public void setSurroundFacil(String surroundFacil) {
		this.surroundFacil = surroundFacil;
	}
	public String getRealInform() {
		return realInform;
	}
	public void setRealInform(String realInform) {
		this.realInform = realInform;
	}
	public String getAdministrationCost() {
		return administrationCost;
	}
	public void setAdministrationCost(String administrationCost) {
		this.administrationCost = administrationCost;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProductPhoto() {
		return productPhoto;
	}
	public void setProductPhoto(String productPhoto) {
		this.productPhoto = productPhoto;
	}
	public String getUntactContract() {
		return untactContract;
	}
	public void setUntactContract(String untactContract) {
		this.untactContract = untactContract;
	}
	public Date getUseApproveDate() {
		return useApproveDate;
	}
	public void setUseApproveDate(Date useApproveDate) {
		this.useApproveDate = useApproveDate;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	
}
