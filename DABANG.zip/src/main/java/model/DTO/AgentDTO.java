package model.DTO;

public class AgentDTO {
	String agentNo;
	String exponentName;
	String exponentTel;
	String corporateNo;
	String agentName;
	String agentAddr;
	String agentTel;
	String agentEmail;
	String agentId;
	String agentPw;
    
	public String getExponentName() {
		return exponentName;
	}

	public void setExponentName(String exponentName) {
		this.exponentName = exponentName;
	}

	public String getExponentTel() {
		return exponentTel;
	}

	public void setExponentTel(String exponentTel) {
		this.exponentTel = exponentTel;
	}

	public String getAgentNo() {
		return agentNo;
	}

	public void setAgentNo(String agentNo) {
		this.agentNo = agentNo;
	}

	public String getCorporateNo() {
		return corporateNo;
	}

	public void setCorporateNo(String corporateNo) {
		this.corporateNo = corporateNo;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getAgentAddr() {
		return agentAddr;
	}

	public void setAgentAddr(String agentAddr) {
		this.agentAddr = agentAddr;
	}

	public String getAgentTel() {
		return agentTel;
	}

	public void setAgentTel(String agentTel) {
		this.agentTel = agentTel;
	}

	public String getAgentEmail() {
		return agentEmail;
	}

	public void setAgentEmail(String agentEmail) {
		this.agentEmail = agentEmail;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getAgentPw() {
		return agentPw;
	}

	public void setAgentPw(String agentPw) {
		this.agentPw = agentPw;
	}

}
