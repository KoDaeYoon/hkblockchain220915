package model.DTO;

import java.util.Date;

public class InquiryDTO {
	Date inquiryDate;
	String inquiryType;
	String inquirySubject;
	String inquiryContent;
	String inquiryImage1;
	String inquiryImage2;
	String inquiryImage3;
	String memNo;
	String empNo;
	String answerReply;
	String answerDate;
	String inquiryNo;
	
	
	
	public String getInquiryNo() {
		return inquiryNo;
	}
	public void setInquiryNo(String inquiryNo) {
		this.inquiryNo = inquiryNo;
	}
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getAnswerReply() {
		return answerReply;
	}
	public void setAnswerReply(String answerReply) {
		this.answerReply = answerReply;
	}
	public String getAnswerDate() {
		return answerDate;
	}
	public void setAnswerDate(String answerDate) {
		this.answerDate = answerDate;
	}
	public String getMemNo() {
		return memNo;
	}
	public void setMemNo(String memNo) {
		this.memNo = memNo;
	}
	public Date getInquiryDate() {
		return inquiryDate;
	}
	public void setInquiryDate(Date inquiryDate) {
		this.inquiryDate = inquiryDate;
	}
	public String getInquiryType() {
		return inquiryType;
	}
	public void setInquiryType(String inquiryType) {
		this.inquiryType = inquiryType;
	}
	public String getInquirySubject() {
		return inquirySubject;
	}
	public void setInquirySubject(String inquirySubject) {
		this.inquirySubject = inquirySubject;
	}
	public String getInquiryContent() {
		return inquiryContent;
	}
	public void setInquiryContent(String inquiryContent) {
		this.inquiryContent = inquiryContent;
	}
	public String getInquiryImage1() {
		return inquiryImage1;
	}
	public void setInquiryImage1(String inquiryImage1) {
		this.inquiryImage1 = inquiryImage1;
	}
	public String getInquiryImage2() {
		return inquiryImage2;
	}
	public void setInquiryImage2(String inquiryImage2) {
		this.inquiryImage2 = inquiryImage2;
	}
	public String getInquiryImage3() {
		return inquiryImage3;
	}
	public void setInquiryImage3(String inquiryImage3) {
		this.inquiryImage3 = inquiryImage3;
	}
	
	
	
	
}
