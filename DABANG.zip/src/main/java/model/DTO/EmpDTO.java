package model.DTO;

import java.util.Date;

public class EmpDTO {
	String empNo;
	String empPw;
	String empFirstName;
	String empLastName;
	String empGender;
	String empPhone;
	Date empBirth;
	Long empSal;
	Date empHireDate;
	String empDepartmentName;
	String empJobTitle;
	String empAddr;
	String empAddrDetail;
	String empPostCode;
	String employeePw;
	
	public String getEmployeePw() {
		return employeePw;
	}
	public void setEmployeePw(String employeePw) {
		this.employeePw = employeePw;
	}
	public String getEmpPostCode() {
		return empPostCode;
	}
	public void setEmpPostCode(String empPostCode) {
		this.empPostCode = empPostCode;
	}
	public String getEmpAddrDetail() {
		return empAddrDetail;
	}
	public void setEmpAddrDetail(String empAddrDetail) {
		this.empAddrDetail = empAddrDetail;
	}
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getEmpPw() {
		return empPw;
	}
	public void setEmpPw(String empPw) {
		this.empPw = empPw;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getEmpPhone() {
		return empPhone;
	}
	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}
	public Date getEmpBirth() {
		return empBirth;
	}
	public void setEmpBirth(Date empBirth) {
		this.empBirth = empBirth;
	}
	public Long getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Long empSal) {
		this.empSal = empSal;
	}
	public Date getEmpHireDate() {
		return empHireDate;
	}
	public void setEmpHireDate(Date empHireDate) {
		this.empHireDate = empHireDate;
	}
	public String getEmpDepartmentName() {
		return empDepartmentName;
	}
	public void setEmpDepartmentName(String empDepartmentName) {
		this.empDepartmentName = empDepartmentName;
	}
	public String getEmpJobTitle() {
		return empJobTitle;
	}
	public void setEmpJobTitle(String empJobTitle) {
		this.empJobTitle = empJobTitle;
	}
	public String getEmpAddr() {
		return empAddr;
	}
	public void setEmpAddr(String empAddr) {
		this.empAddr = empAddr;
	}
	
	
}
